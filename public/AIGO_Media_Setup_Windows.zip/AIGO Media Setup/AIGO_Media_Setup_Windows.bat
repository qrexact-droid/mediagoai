@echo off
title AIGO Media - AI Business Setup
color 0A

:: ============================================
:: AIGO Media AI Business Assistant
:: Windows Installer
:: ============================================

:: Start the GUI installer in browser first
set PORT=8899
set SCRIPT_DIR=%~dp0
set WORKSPACE=%USERPROFILE%\AIGOMedia

:: Kill anything on port 8899
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :%PORT%') do taskkill /PID %%a /F >nul 2>&1

:: Start local server for installer UI
start /b python -m http.server %PORT% --bind 127.0.0.1 --directory "%SCRIPT_DIR%" >nul 2>&1
timeout /t 2 /nobreak >nul

:: Open branded installer in browser
start "" "http://127.0.0.1:%PORT%/installer_ui.html"

:: Now run the actual installation silently
echo.
echo  Installing AIGO Media AI Assistant...
echo  Please wait - this takes 5-10 minutes
echo  Do not close this window
echo.

:: ── Check/Install Chocolatey (Windows package manager) ──────────
where choco >nul 2>&1
if %errorlevel% neq 0 (
    echo  [1/6] Installing package manager...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))" >nul 2>&1
) else (
    echo  [1/6] Package manager ready
)

:: ── Node.js ──────────────────────────────────────────────────────
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [2/6] Installing Node.js...
    choco install nodejs -y >nul 2>&1
    :: Refresh PATH
    call refreshenv >nul 2>&1
) else (
    echo  [2/6] Node.js ready
)

:: ── Python ───────────────────────────────────────────────────────
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo  [3/6] Installing Python...
    choco install python -y >nul 2>&1
    call refreshenv >nul 2>&1
) else (
    echo  [3/6] Python ready
)

:: ── Python packages ──────────────────────────────────────────────
echo  [4/6] Installing automation tools...
python -m pip install playwright anthropic --quiet >nul 2>&1
python -m playwright install chromium >nul 2>&1

:: ── OpenClaw ─────────────────────────────────────────────────────
where openclaw >nul 2>&1
if %errorlevel% neq 0 (
    echo  [5/6] Installing AI engine...
    npm install -g openclaw@latest >nul 2>&1
) else (
    echo  [5/6] AI engine ready - updating...
    npm install -g openclaw@latest >nul 2>&1
)

:: ── Setup workspace ──────────────────────────────────────────────
echo  [6/6] Configuring your assistant...
mkdir "%WORKSPACE%\config" >nul 2>&1
mkdir "%WORKSPACE%\memory" >nul 2>&1
mkdir "%WORKSPACE%\scripts" >nul 2>&1

:: Copy workspace files
if exist "%SCRIPT_DIR%workspace_files\" (
    xcopy "%SCRIPT_DIR%workspace_files\*" "%WORKSPACE%\" /E /Y /Q >nul 2>&1
)

:: Configure OpenClaw
mkdir "%USERPROFILE%\.openclaw" >nul 2>&1
if not exist "%USERPROFILE%\.openclaw\openclaw.json" (
    echo { > "%USERPROFILE%\.openclaw\openclaw.json"
    echo   "agents": { >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo     "defaults": { >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo       "model": { "primary": "anthropic/claude-sonnet-4-6" }, >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo       "workspace": "%WORKSPACE:\=\\%" >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo     } >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo   }, >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo   "tools": { "profile": "coding" }, >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo   "commands": { "native": "auto", "nativeSkills": "auto", "restart": true }, >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo   "gateway": { "port": 18789, "mode": "local", "bind": "loopback" } >> "%USERPROFILE%\.openclaw\openclaw.json"
    echo } >> "%USERPROFILE%\.openclaw\openclaw.json"
)

:: Start OpenClaw gateway
start /b openclaw gateway start >nul 2>&1

:: ── Wait for OpenClaw to actually be ready (poll port 18789) ─────
echo  [6/6] Waiting for AI engine to start...
set MAX_WAIT=120
set WAITED=0

:WAIT_LOOP
timeout /t 2 /nobreak >nul
set /a WAITED=%WAITED%+2

:: Try to connect to port 18789
powershell -Command "try { $r=(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',18789); exit 0 } catch { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 goto READY

:: Also try HTTP ping as backup
powershell -Command "try { (Invoke-WebRequest -Uri 'http://127.0.0.1:18789' -TimeoutSec 2 -UseBasicParsing).StatusCode | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 goto READY

if %WAITED% geq %MAX_WAIT% (
    echo.
    echo  WARNING: AI engine took longer than expected to start.
    echo  Try opening manually: http://127.0.0.1:18789
    echo.
    goto DONE
)

if %WAITED% lss 10 (
    echo  Starting...
) else (
    echo  Still starting... (%WAITED%s)
)
goto WAIT_LOOP

:READY
:: ── Done ─────────────────────────────────────────────────────────
echo.
echo  ================================================
echo   Installation Complete!
echo  ================================================
echo.
echo  Opening your AI assistant...
echo.

:: Small extra pause so the UI fully loads
timeout /t 2 /nobreak >nul

:: Open OpenClaw — it's confirmed running
start "" "http://127.0.0.1:18789"

:DONE
echo  Your AI assistant is now running at:
echo  http://127.0.0.1:18789
echo.
echo  Press any key to close this window...
pause >nul
