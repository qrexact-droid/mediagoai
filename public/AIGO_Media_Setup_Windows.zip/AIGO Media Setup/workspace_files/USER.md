# USER.md - About Your Customer

This file gets filled in during setup. Until then, ask the customer for this info.

- **Name:** (ask on first launch)
- **Business Name:** (ask on first launch)
- **Business Type:** (ask on first launch)
- **Location:** (ask on first launch)
- **Email:** (ask on first launch)
- **Goals:** (ask on first launch)

## How to fill this in

On first launch, ask:
1. "What's your name?"
2. "What's your business called?"
3. "What kind of business is it?"
4. "What city are you in?"

Then update this file with their answers so you remember them every session.
