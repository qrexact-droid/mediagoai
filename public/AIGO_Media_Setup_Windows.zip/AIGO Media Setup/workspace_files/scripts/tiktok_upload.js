const { chromium } = require('playwright');
const fs = require('fs');

const VIDEO_PATH = process.argv[2];
const CAPTION = process.argv[3] || 'When the game gets real 😤 #ronmegagaming #gaming #gamer #Shorts';

if (!VIDEO_PATH) { console.error('Usage: node tiktok_upload2.js <video_path> [caption]'); process.exit(1); }

(async () => {
  const rawCookies = JSON.parse(fs.readFileSync('~/AIGOMedia/config/tiktok_cookies.json'));
  const cookies = rawCookies.map(c => ({
    name: c.name, value: c.value,
    domain: c.domain.startsWith('.') ? c.domain : '.' + c.domain,
    path: c.path || '/', httpOnly: false, secure: true, sameSite: 'None'
  }));

  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  });
  await ctx.addCookies(cookies);
  const page = await ctx.newPage();

  console.log('Loading TikTok Studio upload...');
  await page.goto('https://www.tiktok.com/tiktokstudio/upload', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(5000);

  // Show hidden file input and upload
  console.log('Uploading file...');
  await page.evaluate(() => {
    const input = document.querySelector('input[type="file"][accept="video/*"]');
    if (input) {
      input.style.cssText = 'display:block!important;opacity:1!important;visibility:visible!important;position:fixed;top:0;left:0;z-index:9999;width:100px;height:100px;';
    }
  });
  await page.waitForTimeout(500);
  const fileInput = await page.waitForSelector('input[type="file"][accept="video/*"]', { timeout: 10000 });
  await fileInput.setInputFiles(VIDEO_PATH);
  console.log('File set — waiting for upload to process (30s)...');
  await page.waitForTimeout(30000);

  await page.screenshot({ path: '~/AIGOMedia/config/tt2_after_upload.png' });

  // Dismiss copyright/notification modal if present
  console.log('Checking for modals...');
  await page.evaluate(() => {
    // Remove floating portal overlays that block clicks
    document.querySelectorAll('[id*="floating"], [class*="TUXModal"], [class*="overlay"]').forEach(el => {
      if (el.style) el.style.pointerEvents = 'none';
    });
  });
  await page.waitForTimeout(1000);

  // Fill caption using the DraftEditor
  console.log('Setting caption...');
  try {
    // TikTok uses DraftJS editor for caption
    const editor = await page.waitForSelector(
      '.DraftEditor-root [contenteditable], [class*="caption-wrapper"] [contenteditable], [data-contents]',
      { timeout: 15000 }
    );
    // Click at the beginning of the field
    await editor.evaluate(el => { el.focus(); });
    await page.keyboard.press('Control+a');
    await page.keyboard.press('Meta+a');
    await page.keyboard.press('Backspace');
    await page.waitForTimeout(300);
    await page.keyboard.type(CAPTION.slice(0, 150), { delay: 20 });
    console.log('Caption typed.');
    await page.waitForTimeout(2000);
  } catch(e) {
    console.log('Caption error (continuing anyway):', e.message.split('\n')[0]);
  }

  await page.screenshot({ path: '~/AIGOMedia/config/tt2_caption.png' });

  // Find and click the Post button — scroll down first
  console.log('Looking for Post button...');
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);

  try {
    // Find Post button by text content
    const postBtn = await page.evaluateHandle(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      return buttons.find(b => {
        const text = b.innerText?.trim();
        return text === 'Post' || text === 'Publish';
      });
    });
    
    if (postBtn && await postBtn.asElement()) {
      // Force click via JS to bypass any overlay
      await page.evaluate(btn => btn.click(), await postBtn.asElement());
      console.log('Post button clicked!');
      await page.waitForTimeout(10000);
      await page.screenshot({ path: '~/AIGOMedia/config/tt2_posted.png' });
      const url = page.url();
      console.log('Post-click URL:', url);
      console.log('TikTok: SUCCESS!');
    } else {
      console.log('Post button not found via text search');
      // Dump all buttons
      const btns = await page.evaluate(() => 
        Array.from(document.querySelectorAll('button')).map(b => b.innerText?.trim()).filter(t => t)
      );
      console.log('Available buttons:', btns);
      await page.screenshot({ path: '~/AIGOMedia/config/tt2_error.png' });
    }
  } catch(e) {
    console.error('Post click error:', e.message.split('\n')[0]);
    await page.screenshot({ path: '~/AIGOMedia/config/tt2_final.png' });
  }

  await browser.close();
})().catch(e => { console.error('FATAL:', e.message); process.exit(1); });
