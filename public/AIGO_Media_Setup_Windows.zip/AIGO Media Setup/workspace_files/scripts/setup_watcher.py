#!/usr/bin/env python3
"""
MediaGoAI Setup Watcher
Monitors ~/Desktop/MediaGoAI Setup/ for changes.
When a user fills out a setup file, detects it and notifies OpenClaw.
Runs automatically via cron every minute.
"""

import os, json
from datetime import datetime
from pathlib import Path

SETUP_DIR = os.path.expanduser('~/Desktop/MediaGoAI Setup')
STATE_FILE = os.path.expanduser('~/.openclaw/workspace/memory/setup_watcher_state.json')

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}

def save_state(state):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def parse_setup_file(filepath):
    """Parse a key=value setup file."""
    data = {}
    try:
        with open(filepath) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    data[key.strip()] = val.strip()
    except:
        pass
    return data

def is_filled_out(data, required_keys):
    """Check if any required fields have been filled in."""
    for key in required_keys:
        if data.get(key) and data[key] not in ('', 'NO', 'NOT_STARTED'):
            return True
    return False

def check_setup_files():
    if not os.path.exists(SETUP_DIR):
        return

    state = load_state()
    notifications = []

    files = {
        'social_media.txt':    {'required': ['BUSINESS_NAME', 'TWITTER', 'TIKTOK', 'FACEBOOK'], 'service': 'social_media'},
        'website.txt':         {'required': ['BUSINESS_NAME', 'EMAIL'], 'service': 'website'},
        'content_creator.txt': {'required': ['CHANNEL_NAME', 'YOUTUBE', 'TIKTOK'], 'service': 'content_creator'},
        'sell_online.txt':     {'required': ['PRODUCT_NAME', 'PRICE', 'STRIPE_EMAIL'], 'service': 'sell_online'},
    }

    for filename, config in files.items():
        filepath = os.path.join(SETUP_DIR, filename)
        if not os.path.exists(filepath):
            continue

        # Check modification time
        mtime = os.path.getmtime(filepath)
        last_seen = state.get(filename, {}).get('mtime', 0)
        last_status = state.get(filename, {}).get('status', 'NOT_STARTED')

        if mtime <= last_seen:
            continue  # No changes

        # File was modified
        data = parse_setup_file(filepath)
        current_status = data.get('STATUS', 'NOT_STARTED')

        if current_status == 'NOT_STARTED' and is_filled_out(data, config['required']):
            # User filled it out! Queue it up
            notifications.append({
                'service': config['service'],
                'filename': filename,
                'data': data
            })

            # Update STATUS in the file
            try:
                content = open(filepath).read()
                content = content.replace('STATUS=NOT_STARTED', 'STATUS=QUEUED')
                content = content.replace(f"LAST_UPDATED=", f"LAST_UPDATED={datetime.now().strftime('%Y-%m-%d %H:%M')}")
                with open(filepath, 'w') as f:
                    f.write(content)
            except:
                pass

        state[filename] = {'mtime': mtime, 'status': current_status}

    save_state(state)

    if notifications:
        # Save to a queue file that OpenClaw checks
        queue_file = os.path.expanduser('~/.openclaw/workspace/memory/setup_queue.json')
        existing = []
        if os.path.exists(queue_file):
            try:
                with open(queue_file) as f:
                    existing = json.load(f)
            except:
                existing = []

        existing.extend(notifications)
        with open(queue_file, 'w') as f:
            json.dump(existing, f, indent=2)

        print(f"✅ {len(notifications)} new service(s) queued: {[n['service'] for n in notifications]}")
    else:
        print("No changes detected.")

if __name__ == '__main__':
    check_setup_files()
