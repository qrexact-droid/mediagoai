/**
 * RonMega Gaming — Facebook Story Uploader
 * Posts a video to Facebook Stories
 */
const { chromium } = require('playwright');
const fs = require('fs');

const VIDEO_PATH = process.argv[2];

if (!VIDEO_PATH || !fs.existsSync(VIDEO_PATH)) {
  console.error('Usage: node fb_story.js <video_path>');
  process.exit(1);
}

(async () => {
  const rawCookies = JSON.parse(fs.readFileSync('~/AIGOMedia/config/fb_cookies.json'));
  const cookies = rawCookies.map(c => ({
    name: c.name, value: c.value,
    domain: c.domain.startsWith('.') ? c.domain : '.' + c.domain,
    path: c.path || '/', httpOnly: false, secure: true, sameSite: 'None'
  }));

  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 }
  });
  await ctx.addCookies(cookies);
  const page = await ctx.newPage();

  console.log('Loading Facebook for Story...');
  await page.goto('https://www.facebook.com', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(4000);

  // Click "Create story" button
  console.log('Looking for Create Story button...');
  const storyClicked = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('a, [role="button"], button, span'));
    const btn = els.find(e => (e.innerText || e.getAttribute('aria-label') || '').toLowerCase().includes('create story'));
    if (btn) { btn.click(); return true; }
    return false;
  });

  if (!storyClicked) {
    // Try navigating directly to story creation
    await page.goto('https://www.facebook.com/stories/create', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(4000);
  }

  await page.waitForTimeout(3000);
  await page.screenshot({ path: '~/AIGOMedia/config/fb_story_step1.png' });

  // Look for video/photo upload option in story creator
  const uploaded = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('input[type="file"]'));
    if (els.length > 0) {
      els[0].style.cssText = 'display:block!important;opacity:1!important;position:fixed;top:0;left:0;z-index:99999;';
      return true;
    }
    return false;
  });

  if (uploaded) {
    const fileInput = await page.$('input[type="file"]');
    await fileInput.setInputFiles(VIDEO_PATH);
    console.log('Video attached to story, waiting...');
    await page.waitForTimeout(15000);
    await page.screenshot({ path: '~/AIGOMedia/config/fb_story_step2.png' });
  } else {
    // Click "Create video story" option
    const videoStoryClicked = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll('[role="button"], button, div'));
      const btn = els.find(e => (e.innerText || '').toLowerCase().includes('video story') || 
                                (e.innerText || '').toLowerCase().includes('create video'));
      if (btn) { btn.click(); return true; }
      return false;
    });
    await page.waitForTimeout(3000);
    const fi = await page.$('input[type="file"]');
    if (fi) {
      await fi.setInputFiles(VIDEO_PATH);
      await page.waitForTimeout(15000);
    }
  }

  // Click Share to Story
  for (let i = 0; i < 5; i++) {
    const result = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('[role="button"], button'));
      const shareBtn = btns.find(b => {
        const t = (b.innerText || b.getAttribute('aria-label') || '').toLowerCase();
        return t === 'share to story' || t === 'share' || t === 'post to story' || t === 'add to story';
      });
      if (shareBtn) { shareBtn.click(); return 'clicked'; }
      return btns.map(b => (b.innerText || '').trim()).filter(t => t).slice(0, 10);
    });

    if (result === 'clicked') {
      console.log('Story posted! SUCCESS');
      await page.waitForTimeout(5000);
      break;
    }
    console.log(`Attempt ${i+1} buttons:`, result);
    await page.waitForTimeout(3000);
  }

  await page.screenshot({ path: '~/AIGOMedia/config/fb_story_final.png' });
  await browser.close();
})().catch(e => console.error('FATAL:', e.message));
