const { chromium } = require('playwright');
const fs = require('fs');

const VIDEO_PATH = process.argv[2];
const CAPTION = process.argv[3] || 'When the game gets real 😤 #ronmegagaming #gaming #gamer';

(async () => {
  const rawCookies = JSON.parse(fs.readFileSync('~/AIGOMedia/config/fb_cookies.json'));
  const cookies = rawCookies.map(c => ({
    name: c.name, value: c.value,
    domain: c.domain.startsWith('.') ? c.domain : '.' + c.domain,
    path: c.path || '/', httpOnly: false, secure: true, sameSite: 'None'
  }));

  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 }
  });
  await ctx.addCookies(cookies);
  const page = await ctx.newPage();

  console.log('Loading Facebook...');
  await page.goto('https://www.facebook.com', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(4000);

  // Open photo/video composer
  console.log('Opening composer...');
  const photoVideoBtn = await page.waitForSelector('[aria-label="Photo/video"]', { timeout: 10000 });
  await photoVideoBtn.click();
  await page.waitForTimeout(2000);

  // Upload file
  await page.evaluate(() => {
    document.querySelectorAll('input[type="file"]').forEach(el => {
      el.style.cssText = 'display:block!important;opacity:1!important;visibility:visible!important;position:fixed;top:10px;left:10px;z-index:99999;';
    });
  });
  const fileInput = await page.$('input[type="file"]');
  await fileInput.setInputFiles(VIDEO_PATH);
  console.log('File uploading, waiting 25s...');
  await page.waitForTimeout(25000);

  // Type caption first
  try {
    const textbox = await page.waitForSelector('[contenteditable="true"][aria-label*="mind"], [contenteditable="true"][role="textbox"]', { timeout: 5000 });
    await textbox.click();
    await page.keyboard.type(CAPTION, { delay: 15 });
    console.log('Caption typed');
    await page.waitForTimeout(1000);
  } catch(e) { console.log('Caption skip'); }

  // Click "Next" button
  console.log('Clicking Next...');
  const nextClicked = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('[role="button"], button'));
    const nextBtn = btns.find(b => (b.innerText || '').trim() === 'Next');
    if (nextBtn) { nextBtn.click(); return true; }
    return false;
  });
  console.log('Next clicked:', nextClicked);
  await page.waitForTimeout(5000);
  await page.screenshot({ path: '~/AIGOMedia/config/fb5_after_next.png' });

  // Try to enable "Share to Instagram" toggle if visible
  const igShared = await page.evaluate(() => {
    // Look for Instagram toggle/checkbox in the sharing options
    const els = Array.from(document.querySelectorAll('[role="checkbox"], input[type="checkbox"], [role="switch"]'));
    const igToggle = els.find(e => {
      const label = (e.getAttribute('aria-label') || e.closest('label')?.innerText || '').toLowerCase();
      return label.includes('instagram');
    });
    if (igToggle) {
      // Only click if not already checked
      const checked = igToggle.getAttribute('aria-checked') === 'true' || igToggle.checked;
      if (!checked) igToggle.click();
      return true;
    }
    // Also try finding by nearby text
    const allEls = Array.from(document.querySelectorAll('*'));
    const igLabel = allEls.find(e => e.children.length === 0 && (e.innerText || '').toLowerCase().includes('share to instagram'));
    if (igLabel) {
      igLabel.closest('[role="checkbox"], label, [role="switch"]')?.click();
      return true;
    }
    return false;
  });
  if (igShared) {
    console.log('Instagram share toggle enabled ✅');
    await page.waitForTimeout(1500);
  } else {
    console.log('Instagram share toggle not found (may not be linked or already on)');
  }

  // Now look for Post button
  for (let attempt = 0; attempt < 5; attempt++) {
    const result = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('[role="button"], button'));
      const postBtn = btns.find(b => (b.innerText || b.getAttribute('aria-label') || '').trim() === 'Post');
      if (postBtn) { postBtn.click(); return 'clicked'; }
      // Maybe there's another Next
      const nextBtn = btns.find(b => (b.innerText || '').trim() === 'Next');
      if (nextBtn) { nextBtn.click(); return 'next'; }
      return btns.map(b => (b.innerText || b.getAttribute('aria-label') || '').trim()).filter(t => t).slice(0, 15);
    });

    if (result === 'clicked') {
      console.log('FB: Post button clicked!');
      await page.waitForTimeout(10000);
      await page.screenshot({ path: '~/AIGOMedia/config/fb5_posted.png' });
      console.log('FB: SUCCESS!');
      break;
    } else if (result === 'next') {
      console.log(`Clicked another Next (attempt ${attempt + 1})`);
      await page.waitForTimeout(4000);
      await page.screenshot({ path: `~/AIGOMedia/config/fb5_step${attempt}.png` });
    } else {
      console.log(`Attempt ${attempt + 1} - buttons:`, result);
      await page.waitForTimeout(3000);
    }
  }

  await browser.close();
})().catch(e => console.error('FATAL:', e.message));
