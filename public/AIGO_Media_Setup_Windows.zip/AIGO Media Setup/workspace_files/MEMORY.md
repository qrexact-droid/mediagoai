# MEMORY.md - Long-Term Memory

This file stores everything important about this customer and their business.
Update it as you learn more. Read it every session.

## Customer Info
(filled in during setup)

## Active Projects
(added as customer sets things up)

## What's Running
(automation, websites, social accounts connected)

## Important Notes
(anything worth remembering long-term)
