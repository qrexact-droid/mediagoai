#!/usr/bin/env python3
# WUPP Content Calendar — Week 2
# More varied angles: comparisons, storytelling, DeFi education, viral hooks
# Rule: never repeat week 1 content. Mix energy.

CONTENT_WEEK2 = {
    # MONDAY
    "MON_7AM": {
        "text": "The difference between week 1 and month 6?\n\nThe people who showed up in week 1.\n\nWUPP is in week 1 right now.\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter #earlybird",
        "type": "hype"
    },
    "MON_12PM": {
        "text": "Let's compare:\n\nMost meme coins:\n❌ Anonymous team\n❌ Unlocked liquidity\n❌ No vesting\n❌ Mint not revoked\n\nWUPP:\n✅ Transparent roadmap\n✅ Locked liquidity\n✅ 12-month dev vest\n✅ Mint revoked\n\nYou decide.\nwuppcoin.io\n#Solana #WUPP #DeFi #memecoin",
        "type": "education"
    },
    "MON_9PM": {
        "text": "The worst feeling in crypto?\n\nFinding out about a 100x after it happened.\n\nDon't let WUPP be that coin.\nwuppcoin.io\n#Solana #WUPP #CryptoTwitter #altcoin #memecoin",
        "type": "hype"
    },

    # TUESDAY
    "TUE_7AM": {
        "text": "Every morning I see two types of people.\n\nType A: checks price, panics, sells.\nType B: checks their stack, adds more, builds.\n\nType B always wins.\nBe Type B.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #crypto #hustle",
        "type": "culture"
    },
    "TUE_12PM": {
        "text": "Here is what Raydium listing actually means:\n\n→ Instant price discovery\n→ Anyone can buy with any SOL wallet\n→ Liquidity locked in pool = no rug\n→ Jupiter picks it up automatically\n→ Dexscreener chart goes live\n\nAll of this is already planned.\nwuppcoin.io\n#Solana #WUPP #DeFi #Raydium #memecoin",
        "type": "education"
    },
    "TUE_9PM": {
        "text": "If you had put $100 into early Bonk...\nIf you had put $100 into early WIF...\n\nYou know the story.\n\nI am not saying WUPP is them.\nI am saying you already know what early looks like.\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter #SolanaMemecoins",
        "type": "hype"
    },

    # WEDNESDAY
    "WED_7AM": {
        "text": "No VC backing.\nNo pre-sale.\nNo insider allocation.\n\nJust the community and the contract.\n\nThat is the whole thing.\nwuppcoin.io\n#Solana #WUPP #fairlaunch #memecoin #Web3",
        "type": "trust"
    },
    "WED_12PM": {
        "text": "Quick crypto lesson:\n\nLiquidity pool = where trades happen.\nLocked liquidity = nobody can drain it.\nBurn = every tx reduces supply.\n\nWUPP has all three.\n\nNow you know what to look for in every coin.\nwuppcoin.io\n#Solana #WUPP #DeFi #CryptoEducation #memecoin",
        "type": "education"
    },
    "WED_9PM": {
        "text": "Imagine telling someone in 2021 you didn't buy Solana at $1.\n\nNow imagine telling someone in 2027 you didn't buy WUPP during Phase 1.\n\nDon't be that story.\nwuppcoin.io\n#Solana #WUPP #CryptoTwitter #altcoin #memecoin",
        "type": "hype"
    },

    # THURSDAY
    "THU_7AM": {
        "text": "Three things I know for certain:\n\n1. The burn keeps working whether you are watching or not.\n2. The community shows up every day.\n3. The contract is ready.\n\nEverything else is just timing.\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter",
        "type": "culture"
    },
    "THU_12PM": {
        "text": "Community rewards: 10% of supply.\nMarketing fund: 15% of supply.\nDev wallet: locked and vesting.\nPublic sale: 75% of supply.\n\nWho does this tokenomics help most?\n\nThe community. Always.\nwuppcoin.io\n#Solana #WUPP #tokenomics #DeFi #SolanaMemecoins",
        "type": "tokenomics"
    },
    "THU_9PM": {
        "text": "Which would you rather have?\n\nA) A coin that launches hot and rugs\nB) A coin that builds slowly and holds\n\nWe are building B.\n\nReply and let me know your pick.\n#WUPP #Solana #CryptoTwitter #memecoin",
        "type": "engagement"
    },

    # FRIDAY
    "FRI_7AM": {
        "text": "Friday reminder:\n\nWeekends don't stop builders.\nWeekends don't stop the burn mechanism.\nWeekends don't stop the community.\n\nSee you all weekend.\nwuppcoin.io\n#WUPP #Solana #hustle #grind #CryptoTwitter",
        "type": "culture"
    },
    "FRI_12PM": {
        "text": "What anti-snipe protection actually does:\n\n→ Blocks bots from buying all supply in block 1\n→ Max wallet limits stop one wallet from dumping on you\n→ 5-minute delay means humans can actually buy\n\nThis is built in. Not an afterthought.\nwuppcoin.io\n#Solana #WUPP #DeFi #fairlaunch #memecoin",
        "type": "education"
    },
    "FRI_9PM": {
        "text": "End of week check-in:\n\n✅ Community growing\n✅ Contract ready\n✅ Liquidity strategy locked\n✅ Launch timeline on track\n\nPhase 1 is working.\nPhase 2 is coming.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #memecoin #CryptoTwitter",
        "type": "roadmap"
    },

    # SATURDAY
    "SAT_7AM": {
        "text": "The Solana ecosystem runs 24/7.\n\nNo weekends. No downtime.\n400ms block times while you sleep.\n\nThat's why WUPP is on Solana.\nSpeed matters.\nwuppcoin.io\n#Solana #WUPP #Web3 #DeFi #memecoin",
        "type": "education"
    },
    "SAT_12PM": {
        "text": "If WUPP helps even one person:\n\n→ Think bigger\n→ Push harder\n→ Wake up with purpose\n\nThe money is secondary.\nThe movement is primary.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #mindset #CryptoTwitter",
        "type": "culture"
    },
    "SAT_9PM": {
        "text": "Saturday night question:\n\nWhat is one thing you wish you knew before your first crypto investment?\n\nDrop it below. Let's teach each other.\n#WUPP #Solana #CryptoTwitter #Web3",
        "type": "engagement"
    },

    # SUNDAY
    "SUN_7AM": {
        "text": "The scariest thing about WUPP?\n\nIt might actually work.\n\nBuilt right. Launched fair. Community first.\n\nThat formula has worked before.\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter #SolanaMemecoins",
        "type": "hype"
    },
    "SUN_12PM": {
        "text": "One more week of Phase 1 done.\n\nThe mission hasn't changed:\nBuild the community. Protect the supply. Launch when ready.\n\nSee you Monday.\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #memecoin #hustle #Web3",
        "type": "culture"
    },
    "SUN_9PM": {
        "text": "Tomorrow morning:\n\nDon't scroll first.\nDon't check prices first.\nDon't check notifications first.\n\nJust wake up. Push. Build.\n\nEverything else follows.\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #grind #CryptoTwitter",
        "type": "culture"
    },
}
