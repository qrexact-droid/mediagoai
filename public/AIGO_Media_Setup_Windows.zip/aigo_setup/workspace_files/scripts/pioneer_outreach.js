const { chromium } = require('/Users/ronniemack/.npm/_npx/e41f203b7505f1fb/node_modules/playwright');
const path = require('path');

const SESSION_DIR = '/Users/ronniemack/.openclaw/workspace/config/pioneercache_session';
const GMAIL_USER = 'thepioneercache@gmail.com';
const GMAIL_PASS = 'Lkqyysa1227!';

const EMAIL_SUBJECT = 'Quick collab idea — offline survival guide your readers will love';

function getEmailBody(name) {
  return `Hey ${name},

I built something your readers might love: The Pioneer Cache — 34 survival topics packed into a single HTML file that works 100% offline, forever. No app, no subscription, no internet needed. Just $5.99 and they own it permanently.

It covers water purification, fire craft, field first aid, foraging by region and season, food storage, off-grid power, livestock, navigation, and 26 more topics — all in plain English, written for real emergencies.

If you want to share it with your list or your audience, I'm happy to offer an affiliate arrangement or a discount code. No strings — just reply if it sounds like a good fit.

Check it out: thepioneercache.com

— Ron`;
}

// Targets with direct email addresses
const EMAIL_TARGETS = [
  { name: 'Dan', email: 'dan@thesurvivalistblog.net', site: 'The Survivalist Blog' },
  { name: 'Daisy', email: 'hello@theorganicprepper.com', site: 'The Organic Prepper' },
  { name: 'Ken', email: 'ken@modernsurvivalblog.com', site: 'Modern Survival Blog' },
  { name: 'Todd', email: 'todd@prepperwebsite.com', site: 'Prepper Website' },
  { name: 'Patrick', email: 'contact@survivalsullivan.com', site: 'Survival Sullivan' },
  { name: 'Team', email: 'contact@askaprepper.com', site: 'Ask a Prepper' },
  { name: 'Team', email: 'contact@offgridworld.com', site: 'Off Grid World' },
  { name: 'Team', email: 'hello@backdoorsurvival.com', site: 'Backdoor Survival' },
];

const results = {
  emails_sent: [],
  emails_failed: [],
  forms_submitted: [],
  forms_failed: [],
  saashub: null,
  notes: []
};

async function loginToGmail(page) {
  console.log('Navigating to Gmail...');
  await page.goto('https://mail.google.com', { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(3000);
  
  const url = page.url();
  console.log('Current URL:', url);
  
  if (url.includes('accounts.google.com') || url.includes('signin')) {
    console.log('Need to login...');
    // Enter email
    await page.fill('input[type="email"]', GMAIL_USER);
    await page.click('button:has-text("Next"), #identifierNext');
    await page.waitForTimeout(2000);
    
    // Enter password
    await page.fill('input[type="password"]', GMAIL_PASS);
    await page.click('button:has-text("Next"), #passwordNext');
    await page.waitForTimeout(5000);
    
    // Handle 2FA or other prompts if needed
    const postLoginUrl = page.url();
    console.log('Post-login URL:', postLoginUrl);
    
    if (postLoginUrl.includes('accounts.google.com')) {
      // Might be a challenge page - try clicking "Continue" or similar
      try {
        await page.click('button:has-text("Continue")');
        await page.waitForTimeout(3000);
      } catch(e) {}
    }
  }
  
  await page.waitForTimeout(3000);
  const finalUrl = page.url();
  console.log('Final URL after login:', finalUrl);
  return finalUrl.includes('mail.google.com');
}

async function sendGmailEmail(page, toEmail, toName, site) {
  console.log(`\nSending email to ${toEmail} (${site})...`);
  try {
    // Click Compose
    await page.waitForSelector('div[gh="cm"], .T-I.T-I-KE.L3', { timeout: 15000 });
    await page.click('div[gh="cm"], .T-I.T-I-KE.L3');
    await page.waitForTimeout(2000);
    
    // Fill To field
    const toField = await page.waitForSelector('input[name="to"], textarea[name="to"], div[aria-label="To"]', { timeout: 10000 });
    await toField.click();
    await toField.type(toEmail);
    await page.keyboard.press('Tab');
    await page.waitForTimeout(500);
    
    // Fill Subject
    const subjectField = await page.waitForSelector('input[name="subjectbox"]', { timeout: 5000 });
    await subjectField.click();
    await subjectField.fill(EMAIL_SUBJECT);
    
    // Fill Body
    const body = getEmailBody(toName);
    const bodyField = await page.waitForSelector('div[aria-label="Message Body"], div.Am.Al.editable.LW-avf', { timeout: 5000 });
    await bodyField.click();
    await bodyField.fill(body);
    
    // Send
    await page.waitForTimeout(1000);
    await page.click('div[aria-label="Send ‪(Ctrl-Enter)‬"], .T-I.J-J5-Ji.aoO.v7.T-I-atl.L3');
    await page.waitForTimeout(3000);
    
    console.log(`✅ Email sent to ${toEmail}`);
    results.emails_sent.push({ to: toEmail, name: toName, site });
    return true;
  } catch(err) {
    console.error(`❌ Failed to send email to ${toEmail}:`, err.message);
    results.emails_failed.push({ to: toEmail, name: toName, site, error: err.message });
    // Close compose window if open
    try {
      await page.keyboard.press('Escape');
      await page.waitForTimeout(1000);
      await page.keyboard.press('Escape');
    } catch(e) {}
    return false;
  }
}

async function submitModernSurvivalBlog(page) {
  console.log('\nSubmitting contact form at Modern Survival Blog...');
  try {
    await page.goto('https://modernsurvivalblog.com/contact/', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    
    // Look for form fields
    const nameField = await page.$('input[name="your-name"], input[name="name"], input[placeholder*="name" i]');
    const emailField = await page.$('input[name="your-email"], input[name="email"], input[type="email"]');
    const msgField = await page.$('textarea[name="your-message"], textarea[name="message"], textarea');
    
    if (nameField && emailField && msgField) {
      await nameField.fill('Ron');
      await emailField.fill(GMAIL_USER);
      await msgField.fill(getEmailBody('Ken'));
      
      // Submit
      const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
      if (submitBtn) {
        await submitBtn.click();
        await page.waitForTimeout(3000);
        console.log('✅ Modern Survival Blog form submitted');
        results.forms_submitted.push({ site: 'Modern Survival Blog', url: 'https://modernsurvivalblog.com/contact/' });
      } else {
        throw new Error('No submit button found');
      }
    } else {
      console.log('Form fields not found as expected, saving screenshot...');
      await page.screenshot({ path: '/tmp/msb_contact.png' });
      throw new Error('Form fields not found');
    }
    return true;
  } catch(err) {
    console.error('❌ Modern Survival Blog form failed:', err.message);
    results.forms_failed.push({ site: 'Modern Survival Blog', error: err.message });
    return false;
  }
}

async function submitAskAPrepper(page) {
  console.log('\nSubmitting contact form at Ask A Prepper...');
  try {
    await page.goto('https://www.askaprepper.com/contact/', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    
    // Screenshot to see form structure
    await page.screenshot({ path: '/tmp/aap_contact.png' });
    
    const nameField = await page.$('input[name="your-name"], input[name="name"], input[placeholder*="name" i], input[placeholder*="Name" i]');
    const emailField = await page.$('input[name="your-email"], input[name="email"], input[type="email"]');
    const msgField = await page.$('textarea[name="your-message"], textarea[name="message"], textarea');
    
    if (nameField && emailField && msgField) {
      await nameField.fill('Ron');
      await emailField.fill(GMAIL_USER);
      await msgField.fill(getEmailBody('Claude'));
      
      const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
      if (submitBtn) {
        await submitBtn.click();
        await page.waitForTimeout(4000);
        console.log('✅ Ask A Prepper form submitted');
        results.forms_submitted.push({ site: 'Ask A Prepper', url: 'https://www.askaprepper.com/contact/' });
      } else {
        throw new Error('No submit button found');
      }
    } else {
      // Try alternate selectors
      const inputs = await page.$$('input[type="text"]');
      const textareas = await page.$$('textarea');
      const emails = await page.$$('input[type="email"]');
      console.log(`Found: ${inputs.length} text inputs, ${emails.length} email inputs, ${textareas.length} textareas`);
      
      if (inputs.length > 0 && emails.length > 0 && textareas.length > 0) {
        await inputs[0].fill('Ron');
        await emails[0].fill(GMAIL_USER);
        await textareas[0].fill(getEmailBody('Claude'));
        const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
        if (submitBtn) {
          await submitBtn.click();
          await page.waitForTimeout(4000);
          console.log('✅ Ask A Prepper form submitted (alt method)');
          results.forms_submitted.push({ site: 'Ask A Prepper', url: 'https://www.askaprepper.com/contact/' });
        }
      } else {
        throw new Error('Could not find form fields');
      }
    }
    return true;
  } catch(err) {
    console.error('❌ Ask A Prepper form failed:', err.message);
    results.forms_failed.push({ site: 'Ask A Prepper', error: err.message });
    return false;
  }
}

async function submitCityPrepping(page) {
  console.log('\nSubmitting contact form at City Prepping...');
  try {
    await page.goto('https://cityprepping.com/contact/', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    
    await page.screenshot({ path: '/tmp/cp_contact.png' });
    
    // Try to find form fields
    const nameField = await page.$('input[name="name"], input[placeholder*="name" i], input[placeholder*="Name" i]');
    const emailField = await page.$('input[name="email"], input[type="email"]');
    const msgField = await page.$('textarea');
    
    if (nameField && emailField && msgField) {
      await nameField.fill('Ron');
      await emailField.fill(GMAIL_USER);
      await msgField.fill(getEmailBody('Kris'));
      
      const submitBtn = await page.$('input[type="submit"], button[type="submit"], button:has-text("Send"), button:has-text("Submit")');
      if (submitBtn) {
        await submitBtn.click();
        await page.waitForTimeout(4000);
        console.log('✅ City Prepping form submitted');
        results.forms_submitted.push({ site: 'City Prepping', url: 'https://cityprepping.com/contact/' });
      } else {
        throw new Error('No submit button found');
      }
    } else {
      const inputs = await page.$$('input[type="text"]');
      const textareas = await page.$$('textarea');
      const emails = await page.$$('input[type="email"]');
      
      if (inputs.length > 0 && emails.length > 0 && textareas.length > 0) {
        await inputs[0].fill('Ron');
        await emails[0].fill(GMAIL_USER);
        await textareas[0].fill(getEmailBody('Kris'));
        const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
        if (submitBtn) {
          await submitBtn.click();
          await page.waitForTimeout(4000);
          console.log('✅ City Prepping form submitted (alt method)');
          results.forms_submitted.push({ site: 'City Prepping', url: 'https://cityprepping.com/contact/' });
        }
      } else {
        throw new Error('Could not find form fields');
      }
    }
    return true;
  } catch(err) {
    console.error('❌ City Prepping form failed:', err.message);
    results.forms_failed.push({ site: 'City Prepping', error: err.message });
    return false;
  }
}

async function submitCanadianPrepper(page) {
  // Canadian Prepper - try their website first, then YouTube business email
  console.log('\nTrying Canadian Prepper...');
  try {
    // Try their store/website contact
    await page.goto('https://shop.canadianprepper.ca/pages/contact', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    
    await page.screenshot({ path: '/tmp/canprepper_contact.png' });
    
    const nameField = await page.$('input[name="contact[name]"], input[name="name"]');
    const emailField = await page.$('input[name="contact[email]"], input[name="email"], input[type="email"]');
    const msgField = await page.$('textarea[name="contact[body]"], textarea[name="message"], textarea');
    
    if (nameField && emailField && msgField) {
      await nameField.fill('Ron');
      await emailField.fill(GMAIL_USER);
      await msgField.fill(getEmailBody('Nate'));
      
      const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
      if (submitBtn) {
        await submitBtn.click();
        await page.waitForTimeout(4000);
        console.log('✅ Canadian Prepper contact form submitted');
        results.forms_submitted.push({ site: 'Canadian Prepper', url: 'https://shop.canadianprepper.ca/pages/contact' });
        return true;
      }
    }
    
    throw new Error('Form fields not found');
  } catch(err) {
    // Try sending direct Gmail email to known patterns
    console.log('Trying Canadian Prepper via Gmail (guessed email)...');
    results.forms_failed.push({ site: 'Canadian Prepper', error: err.message, note: 'Could not find contact form' });
    results.notes.push('Canadian Prepper: No direct email found. Their contact info not publicly accessible. Recommend reaching via YouTube comments or community tab.');
    return false;
  }
}

async function submitSaaSHub(page) {
  console.log('\nSubmitting to SaaSHub...');
  try {
    await page.goto('https://www.saashub.com/submit', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);
    
    await page.screenshot({ path: '/tmp/saashub_submit.png' });
    
    const url = page.url();
    console.log('SaaSHub URL:', url);
    
    // Check if we need to login/register
    if (url.includes('login') || url.includes('sign')) {
      console.log('SaaSHub requires login...');
      results.saashub = { status: 'requires_login', note: 'SaaSHub submit page requires account. Manual submission needed at https://www.saashub.com/submit' };
      return false;
    }
    
    // Try to find form fields
    const nameField = await page.$('input[name="name"], input[placeholder*="name" i], input[id*="name" i]');
    const urlField = await page.$('input[name="url"], input[placeholder*="url" i], input[type="url"], input[id*="url" i]');
    
    if (nameField && urlField) {
      await nameField.fill('The Pioneer Cache');
      await urlField.fill('https://thepioneercache.com');
      
      // Description
      const descField = await page.$('textarea[name="description"], textarea[placeholder*="description" i], textarea');
      if (descField) {
        await descField.fill('34 survival topics in one offline HTML file. Works 100% without internet. Water, fire, shelter, first aid, foraging, food storage, off-grid power and more. $5.99 instant download — own it forever.');
      }
      
      // Try to select category
      try {
        await page.selectOption('select[name="category"]', { label: 'Productivity' });
      } catch(e) {
        try {
          await page.click('[data-value*="productivity" i], [data-value*="reference" i]');
        } catch(e2) {}
      }
      
      // Submit
      const submitBtn = await page.$('input[type="submit"], button[type="submit"], button:has-text("Submit")');
      if (submitBtn) {
        await submitBtn.click();
        await page.waitForTimeout(5000);
        await page.screenshot({ path: '/tmp/saashub_after.png' });
        console.log('✅ SaaSHub submitted');
        results.saashub = { status: 'submitted', url: 'https://www.saashub.com/submit' };
        return true;
      }
    } else {
      await page.screenshot({ path: '/tmp/saashub_form.png' });
      console.log('SaaSHub form structure unclear, checking page content...');
      const pageText = await page.textContent('body');
      const firstChunk = pageText.substring(0, 500);
      console.log('Page content sample:', firstChunk);
      results.saashub = { status: 'form_not_found', note: 'Could not find form fields. Manual submission needed.', url: 'https://www.saashub.com/submit' };
    }
    return false;
  } catch(err) {
    console.error('❌ SaaSHub submission failed:', err.message);
    results.saashub = { status: 'error', error: err.message };
    return false;
  }
}

async function main() {
  console.log('=== Pioneer Cache Outreach Campaign ===');
  
  const browser = await chromium.launchPersistentContext(SESSION_DIR, {
    headless: false,
    args: ['--no-sandbox', '--disable-blink-features=AutomationControlled'],
    viewport: { width: 1280, height: 900 }
  });
  
  const page = await browser.newPage();
  
  try {
    // Step 1: Login to Gmail
    const loggedIn = await loginToGmail(page);
    
    if (loggedIn) {
      console.log('✅ Gmail session active');
      
      // Send emails to direct addresses
      for (const target of EMAIL_TARGETS) {
        await sendGmailEmail(page, target.email, target.name, target.site);
        await page.waitForTimeout(3000);
      }
    } else {
      console.log('❌ Gmail login failed, skipping direct emails');
      results.notes.push('Gmail login could not be confirmed - check session or credentials');
    }
    
    // Step 2: Contact forms
    await submitModernSurvivalBlog(page);
    await page.waitForTimeout(2000);
    
    await submitAskAPrepper(page);
    await page.waitForTimeout(2000);
    
    await submitCityPrepping(page);
    await page.waitForTimeout(2000);
    
    await submitCanadianPrepper(page);
    await page.waitForTimeout(2000);
    
    // Step 3: SaaSHub
    await submitSaaSHub(page);
    
  } finally {
    await browser.close();
  }
  
  // Print summary
  console.log('\n=== RESULTS SUMMARY ===');
  console.log(JSON.stringify(results, null, 2));
  
  // Write results to file
  const fs = require('fs');
  fs.writeFileSync('/tmp/pioneer_outreach_results.json', JSON.stringify(results, null, 2));
  console.log('\nResults saved to /tmp/pioneer_outreach_results.json');
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
