#!/usr/bin/env python3
"""
YouTube OAuth2 Setup for RonMega Gaming
Run this once to authorize upload access.
Opens a browser for Google login, saves token for future use.
"""

import os, json
from google_auth_oauthlib.flow import InstalledAppFlow
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

SCOPES = ['https://www.googleapis.com/auth/youtube.upload',
          'https://www.googleapis.com/auth/youtube']

TOKEN_FILE = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_token.json'
CREDS_FILE = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_creds.json'

# We'll use a simple OAuth client — Ron needs to create one in Google Cloud Console
# OR we can use yt-dlp's built-in OAuth flow which is simpler
def setup_via_ytdlp():
    """Use yt-dlp's built-in OAuth to get a token."""
    import subprocess
    print("Setting up YouTube auth via yt-dlp OAuth...")
    print("A browser window will open. Log in with mczeallionaire@gmail.com")
    
    result = subprocess.run([
        '/Users/ronniemack/Library/Python/3.9/bin/yt-dlp',
        '--username', 'oauth2',
        '--password', '',
        '--skip-download',
        'https://www.youtube.com/feed/subscriptions'
    ], capture_output=False, text=True)
    print("Auth result:", result.returncode)

if __name__ == '__main__':
    setup_via_ytdlp()
