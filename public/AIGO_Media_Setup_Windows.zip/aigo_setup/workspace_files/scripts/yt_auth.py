#!/usr/bin/env python3
"""
YouTube OAuth2 Authorization — run once to get upload token.
Opens browser for Google login, saves token to config/yt_oauth_token.json
"""
import os
from google_auth_oauthlib.flow import InstalledAppFlow
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
import json

SCOPES = ['https://www.googleapis.com/auth/youtube.upload',
          'https://www.googleapis.com/auth/youtube']

CREDS_FILE = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_creds.json'
TOKEN_FILE  = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_token.json'

def authorize():
    creds = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDS_FILE, SCOPES)
            creds = flow.run_local_server(port=8080, open_browser=True)
        with open(TOKEN_FILE, 'w') as f:
            f.write(creds.to_json())
        print(f'Token saved to {TOKEN_FILE}')
    else:
        print('Already authorized!')
    return creds

if __name__ == '__main__':
    authorize()
    print('YouTube auth complete. Ready to upload.')
