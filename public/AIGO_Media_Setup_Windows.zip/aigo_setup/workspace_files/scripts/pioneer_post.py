#!/usr/bin/env python3
"""
Pioneer Cache Twitter Auto-Poster
Posts promotional tweets with branded image cards on a rotating schedule.
Usage: python3 pioneer_post.py [slot]
Slots: morning | afternoon | evening (defaults by time of day)
"""

import sys, os, random
from datetime import datetime
from playwright.sync_api import sync_playwright

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
IMAGE_DIR = f'{WORKSPACE}/config/pioneer_images'

TWEETS = [
    {
        "text": "When the grid goes down, Google goes with it.\n\nNo WiFi. No signal. No answers.\n\nThat's why I built The Pioneer Cache — 34 survival topics in ONE file. Works 100% offline. Forever.\n\n$5.99. One time. Yours forever.\n→ thepioneercache.com\n\n#prepper #survival #offgrid #SHTF #emergencyprep",
        "card_type": "fear"
    },
    {
        "text": "Most survival courses cost $200+.\n\nThe Pioneer Cache: $5.99\n- 34 survival topics\n- One HTML file\n- Works offline forever\n- Open in any browser\n\nSpend less. Know more.\n\nthepioneercache.com\n\n#prepper #survival #offgrid #homestead",
        "card_type": "value"
    },
    {
        "text": "34 survival topics in one file:\n\n✅ Water purification\n✅ Fire craft\n✅ Foraging by region & season\n✅ Field first aid\n✅ Off-grid power\n✅ Snares & trapping\n✅ Bug-out vs. bug-in\n...and 27 more.\n\nNo app. No internet. Just open it.\n\n$5.99 → thepioneercache.com\n\n#prepper #survival #SHTF #offgrid",
        "card_type": "feature"
    },
    {
        "text": "Preppers: you've got food. Water. Gear.\n\nDo you have the KNOWLEDGE to use it without Google?\n\nThe Pioneer Cache — 34 survival topics. Offline. Forever. $5.99.\n\nThis is the one thing missing from most bug-out plans.\n\nthepioneercache.com\n\n#prepper #bugout #SHTF #survival #offgrid",
        "card_type": "fear"
    },
    {
        "text": "Perfect gift for the prepper who 'already has everything':\n\nThe Pioneer Cache — 34 survival topics in one offline file.\n\nThey'll actually use it. Unlike that $40 multi-tool collecting dust.\n\n$5.99. Instant download.\n→ thepioneercache.com\n\n#prepper #survival #giftideas #homestead",
        "card_type": "gift"
    },
    {
        "text": "Knowledge that works when the grid doesn't.\n\nThe Pioneer Cache:\n→ 34 survival topics\n→ One HTML file\n→ Works offline in any browser\n→ Foraging, first aid, fire, water, shelter, navigation\n\nBuy once. Own it forever.\n\nthepioneercache.com | $5.99\n\n#survival #prepper #offgrid #homestead #SHTF",
        "card_type": "cta"
    },
    {
        "text": "Every prepper thinks about SHTF scenarios.\n\nMost haven't downloaded the knowledge they'd need.\n\nThe Pioneer Cache is that download.\n34 topics. One file. $5.99. Works offline.\n\nthepioneercache.com\n\n#prepper #SHTF #survival #emergencyprep #offgrid",
        "card_type": "fear"
    },
    {
        "text": "You can save it to:\n→ USB drive\n→ Laptop\n→ Old phone\n→ Tablet\n\nAnywhere you can open a browser, The Pioneer Cache works.\n\nNo internet needed. Ever. $5.99 one time.\n\nthepioneercache.com\n\n#prepper #survival #offgrid #SHTF #homestead",
        "card_type": "feature"
    },
]

# Track which tweets have been used (simple rotation)
STATE_FILE = f'{WORKSPACE}/memory/pioneer_twitter_state.json'

def get_next_tweet():
    import json
    state = {}
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE) as f:
                state = json.load(f)
        except:
            state = {}
    
    last_idx = state.get('last_tweet_idx', -1)
    next_idx = (last_idx + 1) % len(TWEETS)
    
    # Add some randomness — sometimes skip ahead
    if random.random() < 0.2 and len(TWEETS) > 3:
        next_idx = random.randint(0, len(TWEETS) - 1)
    
    state['last_tweet_idx'] = next_idx
    state['last_posted'] = datetime.now().isoformat()
    
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)
    
    return TWEETS[next_idx]

def get_image_for_card_type(card_type):
    """Generate a fresh image card for this post."""
    try:
        sys.path.insert(0, f'{WORKSPACE}/scripts')
        from pioneer_image_gen import make_pioneer_card
        
        # 25% chance to skip image (variety)
        if random.random() < 0.25:
            return None
        
        output_path = f"{IMAGE_DIR}/pioneer_post_{card_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        os.makedirs(IMAGE_DIR, exist_ok=True)
        return make_pioneer_card(card_type, output_path)
    except Exception as e:
        print(f"Image gen failed: {e}")
        return None

def post_tweet(text, image_path=None):
    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=f'{WORKSPACE}/config/browser_session',
            headless=True,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled'],
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = browser.new_page()
        page.goto("https://x.com/home")
        page.wait_for_timeout(5000)

        page.click('[data-testid="SideNav_NewTweet_Button"]')
        page.wait_for_timeout(2000)

        tweet_box = page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=10000)
        tweet_box.click()
        page.wait_for_timeout(500)
        page.keyboard.type(text, delay=35)
        page.wait_for_timeout(2000)

        # Attach image
        if image_path and os.path.exists(image_path):
            try:
                media_btn = page.query_selector('[data-testid="attachments"]') or \
                            page.query_selector('[aria-label="Add photos or video"]')
                if media_btn:
                    with page.expect_file_chooser() as fc_info:
                        media_btn.click()
                    fc_info.value.set_files(image_path)
                    page.wait_for_timeout(4000)
                    print(f"Image attached: {os.path.basename(image_path)}")
            except Exception as e:
                print(f"Image attach failed: {e}")

        page.wait_for_timeout(2000)
        # JS click bypasses overlay divs that intercept pointer events
        page.evaluate("""() => {
            const btn = document.querySelector('[data-testid="tweetButtonInline"]')
                     || document.querySelector('[data-testid="tweetButton"]');
            if (btn) btn.click();
        }""")
        page.wait_for_timeout(4000)
        print(f"Posted: {text[:80]}...")
        browser.close()

    # Cleanup image
    if image_path and os.path.exists(image_path):
        try:
            os.remove(image_path)
        except:
            pass

if __name__ == "__main__":
    tweet = get_next_tweet()
    image_path = get_image_for_card_type(tweet["card_type"])
    post_tweet(tweet["text"], image_path)
