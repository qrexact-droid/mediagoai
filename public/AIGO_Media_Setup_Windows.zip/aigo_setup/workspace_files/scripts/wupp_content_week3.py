#!/usr/bin/env python3
# WUPP Content Calendar — Week 3
# Deeper storytelling, holder testimonial style, countdown energy as launch nears

CONTENT_WEEK3 = {
    # MONDAY
    "MON_7AM": {
        "text": "The people building WUPP right now?\n\nThey're not waiting for permission.\nNot waiting for hype.\nNot waiting for a signal.\n\nThey're moving because they choose to move.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #CryptoTwitter #grind",
        "type": "culture"
    },
    "MON_12PM": {
        "text": "Let me explain why WUPP burns matter over time:\n\nDay 1: 1,000,000,000 tokens\nEvery swap burns 1%\n10,000 swaps at avg 1,000 tokens each = 100,000 tokens gone\n\nSmall now. Compounds fast at scale.\n\nMath is doing the work.\nwuppcoin.io\n#Solana #WUPP #tokenomics #DeFi #memecoin",
        "type": "education"
    },
    "MON_9PM": {
        "text": "The biggest mistake in early-stage crypto?\n\nWaiting for confirmation.\n\nBy the time it's confirmed, it's too late.\n\nWUPP is pre-launch. Pre-listing. Pre-everything.\n\nThis is the window.\nwuppcoin.io\n#Solana #WUPP #CryptoTwitter #altcoin #memecoin",
        "type": "hype"
    },

    # TUESDAY
    "TUE_7AM": {
        "text": "Didn't buy BTC at $100.\nDidn't buy ETH at $1.\nDidn't buy SOL at $1.\n\nAt some point you run out of 'I should have' stories.\n\nWUPP is writing a new one right now.\n\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter #crypto",
        "type": "hype"
    },
    "TUE_12PM": {
        "text": "Phase 2 checklist (launching June 2026):\n\n☐ Phantom wallet funded\n☐ Contract deployed via Pump.fun\n☐ Raydium liquidity added\n☐ Liquidity locked (Raydium locker)\n☐ CoinGecko submission\n☐ CoinMarketCap submission\n☐ Contract address published\n\nEvery item has a plan.\nwuppcoin.io\n#Solana #WUPP #DeFi #Raydium #memecoin",
        "type": "roadmap"
    },
    "TUE_9PM": {
        "text": "Fair launch means:\n\nNo pre-sale. No insider bags.\nNo VCs. No preseed.\nJust the community.\n\nEveryone gets in at the same price on day one.\n\nWhen was the last time you saw that?\nwuppcoin.io\n#Solana #WUPP #fairlaunch #DeFi #CryptoTwitter",
        "type": "trust"
    },

    # WEDNESDAY
    "WED_7AM": {
        "text": "The goal isn't to be rich.\n\nThe goal is to be free.\n\nRich is a number. Free is a feeling.\n\nWUPP was built by people who know the difference.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #mindset #CryptoTwitter",
        "type": "culture"
    },
    "WED_12PM": {
        "text": "How Jupiter auto-listing works:\n\nOnce WUPP is on Raydium with a liquidity pool, Jupiter picks it up within hours.\n\nJupiter is the biggest DEX aggregator on Solana.\nMillions of users. Automatic exposure.\n\nNo application. No waitlist. Just build.\nwuppcoin.io\n#Solana #WUPP #DeFi #Jupiter #Raydium",
        "type": "education"
    },
    "WED_9PM": {
        "text": "Reminder:\n\nThe Solana meme coin supercycle wasn't luck.\n\nIt was community.\nIt was timing.\nIt was a movement with energy behind it.\n\nWUPP has all three.\nwuppcoin.io\n#Solana #WUPP #memecoin #SolanaMemecoins #CryptoTwitter",
        "type": "hype"
    },

    # THURSDAY
    "THU_7AM": {
        "text": "Three things the WUPP contract does automatically:\n\n1. Burns 1% of every transaction\n2. Sends 1% to community wallet\n3. Blocks snipe bots on launch\n\nNo human in the loop. Just code.\n\nThis is what trustless means.\nwuppcoin.io\n#Solana #WUPP #DeFi #smartcontract #memecoin",
        "type": "education"
    },
    "THU_12PM": {
        "text": "What community actually means in crypto:\n\nNot just holders.\nNot just hype.\n\nPeople who show up before the launch.\nPeople who build the story before the price.\n\nThat is the WUPP Army.\nwuppcoin.io\n#WUPP #Solana #CryptoTwitter #community #Web3",
        "type": "community"
    },
    "THU_9PM": {
        "text": "Thursday night prompt:\n\nWhat is one thing you built that you are proud of — big or small?\n\nDrop it below. Real ones celebrate real wins.\n#WUPP #Solana #CryptoTwitter #buildingpublicly #Web3",
        "type": "engagement"
    },

    # FRIDAY
    "FRI_7AM": {
        "text": "WUPP is not trying to be the next Doge.\n\nDoge was fun.\nWUPP is purposeful.\n\nFun fades. Purpose compounds.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #memecoin #CryptoTwitter #hustle",
        "type": "culture"
    },
    "FRI_12PM": {
        "text": "What does 'mint revoked' actually mean?\n\nIt means the smart contract can never create new tokens.\nNot by us. Not by anyone.\n\n1 billion tokens. That's it. The number will only go down from here.\n\nScarcity you can verify on-chain.\nwuppcoin.io\n#Solana #WUPP #DeFi #blockchain #memecoin",
        "type": "education"
    },
    "FRI_9PM": {
        "text": "End of week 3.\n\nCommunity: still growing.\nContent: still shipping.\nContract: still ready.\n\nWe have not missed a single day.\n\nPhase 1 is discipline. Phase 2 is reward.\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #grind #CryptoTwitter #memecoin",
        "type": "culture"
    },

    # SATURDAY
    "SAT_7AM": {
        "text": "On Solana, a transaction costs $0.00025.\n\nThat means the burn mechanism activates thousands of times per day at scale.\n\nLow fees + high volume + 1% burn = real deflation.\n\nSolana was the right chain.\nwuppcoin.io\n#Solana #WUPP #DeFi #memecoin #SolanaMemecoins",
        "type": "education"
    },
    "SAT_12PM": {
        "text": "The name was not random.\n\nWe could have called it anything.\n\nWe chose four words that mean something:\nWake Up & Push Purposefully.\n\nEvery morning. Every day. That's the mission.\nwuppcoin.io\n#WUPP #Solana #hustle #mindset #CryptoTwitter",
        "type": "culture"
    },
    "SAT_9PM": {
        "text": "Saturday question:\n\nIf you could go back and tell your past self ONE thing about investing, what would it be?\n\nGo.\n#WUPP #Solana #CryptoTwitter #investing #Web3",
        "type": "engagement"
    },

    # SUNDAY
    "SUN_7AM": {
        "text": "Countdown to Phase 2: ~90 days.\n\nThat is not a lot of time.\nThat is also a lot of time to build.\n\nWe are using every day.\n\nAre you?\nwuppcoin.io\n#WUPP #Solana #hustle #memecoin #CryptoTwitter",
        "type": "hype"
    },
    "SUN_12PM": {
        "text": "Look at the Solana meme coin leaderboard.\n\nEvery project up there had a Phase 1.\nEvery single one.\n\nSome were polished. Most weren't.\nWhat they all had: community before launch.\n\nThat's us right now.\nwuppcoin.io\n#Solana #WUPP #memecoin #SolanaMemecoins #CryptoTwitter",
        "type": "hype"
    },
    "SUN_9PM": {
        "text": "Another week in the books.\n\nMost won't see the work that went into this week.\nThey'll see the launch.\n\nAnd they'll wish they knew sooner.\n\nYou know now.\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #grind #CryptoTwitter #memecoin",
        "type": "culture"
    },
}
