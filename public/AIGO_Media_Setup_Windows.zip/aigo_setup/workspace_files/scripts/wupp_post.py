#!/usr/bin/env python3
# WUPP Auto Twitter Poster — with image support
import json, sys, os, random, tempfile
from datetime import datetime
from playwright.sync_api import sync_playwright
from wupp_content import CONTENT

DAYS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
IMAGE_DIR = f'{WORKSPACE}/config/wupp_images'

def get_post(slot=None):
    """slot = '7AM', '12PM', or '9PM'. Defaults by current hour."""
    day = DAYS[datetime.now().weekday()]
    if not slot:
        hour = datetime.now().hour
        if hour < 10:
            slot = "7AM"
        elif hour < 17:
            slot = "12PM"
        else:
            slot = "9PM"
    key = f"{day}_{slot}"
    entry = CONTENT.get(key, {})
    return entry.get("text", ""), entry.get("type", "culture")

def generate_image_for_post(content_type, slot):
    """Generate a fresh image card for this post."""
    try:
        sys.path.insert(0, WORKSPACE + '/scripts')
        from wupp_image_gen import make_card_for_content_type, make_card, CARD_CONTENT
        
        # 30% chance: skip image (keeps feed varied, avoids looking like a bot)
        if random.random() < 0.30:
            print("No image this post (randomized skip for variety).")
            return None

        output_path = f"{IMAGE_DIR}/wupp_post_{slot}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        os.makedirs(IMAGE_DIR, exist_ok=True)
        path = make_card_for_content_type(content_type, output_path)
        return path
    except Exception as e:
        print(f"Image generation failed (posting text-only): {e}")
        return None

def post_tweet(text, image_path=None):
    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=f'{WORKSPACE}/config/browser_session',
            headless=True,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled'],
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = browser.new_page()
        page.goto("https://x.com/home")
        page.wait_for_timeout(5000)

        page.click('[data-testid="SideNav_NewTweet_Button"]')
        page.wait_for_timeout(2000)

        tweet_box = page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=10000)
        tweet_box.click()
        page.wait_for_timeout(800)
        # Use keyboard.type() — more reliable with React's synthetic events
        page.keyboard.type(text, delay=30)
        page.wait_for_timeout(2500)

        # Attach image if provided
        if image_path and os.path.exists(image_path):
            try:
                # Click the media/image button in composer
                media_btn = page.query_selector('[data-testid="attachments"]')
                if not media_btn:
                    # Try alternate selector
                    media_btn = page.query_selector('[aria-label="Add photos or video"]')
                if media_btn:
                    with page.expect_file_chooser() as fc_info:
                        media_btn.click()
                    file_chooser = fc_info.value
                    file_chooser.set_files(image_path)
                    page.wait_for_timeout(4000)
                    print(f"Image attached: {os.path.basename(image_path)}")
                else:
                    print("Media button not found — posting text only.")
            except Exception as e:
                print(f"Image attach failed: {e} — posting text only.")

        page.wait_for_timeout(1500)

        # Wait for the tweet button to become enabled (React needs time to validate text)
        page.wait_for_timeout(2000)
        # Use JS click to bypass overlay divs that intercept pointer events
        clicked = page.evaluate("""() => {
            const btn = document.querySelector('[data-testid="tweetButtonInline"]') 
                     || document.querySelector('[data-testid="tweetButton"]');
            if (btn) { btn.click(); return true; }
            return false;
        }""")
        page.wait_for_timeout(4000)
        print(f"Posted: {text[:80]}...")
        browser.close()

if __name__ == "__main__":
    slot = None
    if len(sys.argv) > 1:
        slot = sys.argv[1] if sys.argv[1] in ["7AM", "12PM", "9PM"] else None

    text, content_type = get_post(slot)
    if not text:
        print("No content found for this slot.")
        sys.exit(1)

    # Generate image (may return None — that's fine)
    image_path = generate_image_for_post(content_type, slot or "auto")

    post_tweet(text, image_path)

    # Clean up generated image after posting
    if image_path and os.path.exists(image_path):
        try:
            os.remove(image_path)
        except:
            pass
