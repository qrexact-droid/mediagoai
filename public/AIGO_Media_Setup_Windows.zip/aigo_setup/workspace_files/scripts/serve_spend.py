#!/usr/bin/env python3
"""
OpenClaw Spend Dashboard Server
Serves the spend_dashboard.html + /api/spend JSON endpoint.
Run: python3 scripts/serve_spend.py
Open: http://localhost:8787
"""

import json
import os
import sys
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer

# Anthropic claude-sonnet-4-6 pricing per million tokens
PRICING = {
    "input":       3.00,
    "output":      15.00,
    "cache_read":  0.30,
    "cache_write": 3.75,
}

MONTHLY_BUDGET = 200.00  # Ron's $200/mo OpenClaw target

WORKSPACE = Path(__file__).parent.parent
SESSIONS_PATH = Path.home() / ".openclaw" / "agents" / "main" / "sessions" / "sessions.json"
DASHBOARD_PATH = WORKSPACE / "spend_dashboard.html"
PORT = 8787


def calculate_spend():
    if not SESSIONS_PATH.exists():
        return {"error": "sessions.json not found", "cost": 0, "pct": 0}

    with open(SESSIONS_PATH) as f:
        data = json.load(f)

    total_input = total_output = total_cache_read = total_cache_write = 0
    session_count = 0

    for key, session in data.items():
        if not isinstance(session, dict):
            continue
        total_input       += session.get("inputTokens", 0) or 0
        total_output      += session.get("outputTokens", 0) or 0
        total_cache_read  += session.get("cacheRead", 0) or 0
        total_cache_write += session.get("cacheWrite", 0) or 0
        session_count     += 1

    cost = (
        total_input       / 1e6 * PRICING["input"] +
        total_output      / 1e6 * PRICING["output"] +
        total_cache_read  / 1e6 * PRICING["cache_read"] +
        total_cache_write / 1e6 * PRICING["cache_write"]
    )

    pct = min(100, (cost / MONTHLY_BUDGET) * 100)

    if pct >= 80:
        status, label = "red",    "LOW BUDGET — Running hot!"
    elif pct >= 50:
        status, label = "yellow", "MID — On track"
    else:
        status, label = "green",  "GOOD — Budget healthy"

    return {
        "cost": round(cost, 4),
        "budget": MONTHLY_BUDGET,
        "pct": round(pct, 2),
        "status": status,
        "label": label,
        "tokens": {
            "input": total_input,
            "output": total_output,
            "cache_read": total_cache_read,
            "cache_write": total_cache_write,
        },
        "sessions": session_count,
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # Quiet

    def do_GET(self):
        if self.path == "/api/spend" or self.path == "/api/spend/":
            data = calculate_spend()
            body = json.dumps(data).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)

        elif self.path == "/" or self.path == "/index.html":
            if DASHBOARD_PATH.exists():
                body = DASHBOARD_PATH.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.send_header("Content-Length", len(body))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"dashboard not found")
        else:
            self.send_response(404)
            self.end_headers()


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"💰 Spend dashboard: http://localhost:{PORT}")
    print(f"📊 JSON endpoint:  http://localhost:{PORT}/api/spend")
    print(f"   Press Ctrl+C to stop\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
