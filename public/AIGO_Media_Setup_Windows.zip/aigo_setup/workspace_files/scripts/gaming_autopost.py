#!/usr/bin/env python3
"""
RonMega Gaming Auto-Post Pipeline
Watches ~/Desktop/RonMega_Clips/ for new video files.
For each new clip:
  1. Converts to vertical 9:16 Shorts format (max 58s)
  2. Posts to YouTube Shorts via API
  3. Posts to TikTok via browser automation
  4. Posts to Facebook via browser automation

Usage:
  python3 gaming_autopost.py --watch          # Watch folder continuously
  python3 gaming_autopost.py --file clip.mp4  # Post one specific file
  python3 gaming_autopost.py --check          # Just check for pending clips
"""

import os, sys, json, time, random, subprocess, shutil
from datetime import datetime
from pathlib import Path

WORKSPACE   = '/Users/ronniemack/.openclaw/workspace'
CLIPS_DIR   = os.path.expanduser('~/Desktop/RonMega_Clips')
PROCESSED   = f'{WORKSPACE}/config/gaming_processed'
STATE_FILE  = f'{WORKSPACE}/memory/gaming_post_state.json'
FFMPEG      = '/opt/homebrew/bin/ffmpeg'
FFPROBE     = '/opt/homebrew/bin/ffprobe'
NODE        = '/usr/local/bin/node'

os.makedirs(PROCESSED, exist_ok=True)
os.makedirs(CLIPS_DIR, exist_ok=True)

VIDEO_EXTS = {'.mp4', '.mov', '.mkv', '.avi', '.m4v'}

# Per-platform captions — each platform gets its own voice and style
# YouTube: searchable titles, keywords, slightly more formal
# TikTok: raw, short, punchy, lowercase energy
# Facebook: conversational, like you're talking to a friend

CAPTIONS = {
    "brawlhalla": {
        "youtube": [
            "They Had No Idea What Was Coming 😤 | Brawlhalla Clip #brawlhalla #ronmegagaming #gaming #Shorts",
            "That Combo Was NOT Planned 💀 | Brawlhalla Highlights #brawlhalla #gamingclips #Shorts",
            "When Everything Just Clicks in Brawlhalla 🔥 #brawlhalla #ronmegagaming #fightinggames #Shorts",
            "They Came Back... Then Caught These Hands 😅 | Brawlhalla #brawlhalla #gaming #Shorts",
            "No Rematch Button After This One 🎮 | Brawlhalla #brawlhalla #ronmegagaming #Shorts",
        ],
        "tiktok": [
            "bro thought he was safe 💀 #brawlhalla #gaming #fyp #ronmegagaming",
            "nah this one was dirty 😭🔥 #brawlhalla #gamingclips #fyp",
            "they really tried it 😤 #brawlhalla #fyp #gaming #ronmega",
            "the combo that ended the friendship 💀 #brawlhalla #fyp #gamingmoments",
            "locked in different tonight fr #brawlhalla #gaming #fyp #ronmegagaming",
        ],
        "facebook": [
            "They had absolutely no answer for this 😂 drop a 💀 if you felt that one. #RonMegaGaming #Brawlhalla",
            "That was either skill or luck and I'm not saying which one 😅 #RonMegaGaming",
            "Some days the game just flows different. Tonight was one of those nights 🎮🔥",
            "Nah I need a replay on that — even I didn't see that coming 😭 #Brawlhalla #Gaming",
            "The arena doesn't care about your feelings. Neither do I 😤 #RonMegaGaming #Brawlhalla",
        ],
    },
    "warzone": {
        "youtube": [
            "They Thought the Game Was Over... It Wasn't 😤 | Warzone Clip #warzone #callofduty #Shorts",
            "One of Those Rounds You Have to Save 🎯 | Warzone Highlights #warzone #COD #Shorts",
            "The Whole Squad Wasn't Ready 🔥 | Warzone #warzone #callofduty #ronmegagaming #Shorts",
            "How Are They Still Surprised? | Warzone Clip 😅 #warzone #codclips #gaming #Shorts",
            "Third Party? Let Them Come 🎯 | Warzone #warzone #ronmegagaming #callofduty #Shorts",
        ],
        "tiktok": [
            "bro thought the 3rd party would save him 😭 #warzone #cod #fyp #ronmegagaming",
            "they peaked at the wrong time 💀 #warzone #callofduty #fyp #gaming",
            "nah the timing on this was NASTY 🔥 #warzone #fyp #codclips",
            "told you don't push unless you're ready 😤 #warzone #cod #fyp #ronmega",
            "came, saw, did not lose 🎯 #warzone #callofduty #fyp #gamingclips",
        ],
        "facebook": [
            "Some games you're just locked in from the jump. This was one of them 🎯 #RonMegaGaming #Warzone",
            "If you've been gaming long enough you know exactly what happened here 😂 #COD #Warzone",
            "Third party always shows up at the worst time... for them 😤 #RonMegaGaming #Warzone",
            "The boys wanted smoke. The boys got smoke. #Warzone #RonMegaGaming 🔥",
            "Honestly didn't plan that one but I'll take it 😅 #Warzone #CallOfDuty",
        ],
    },
    "default": {
        "youtube": [
            "This Clip Lives in My Head Rent Free 🔥 | RonMega Gaming #gaming #gamingclips #Shorts",
            "Nobody Saw That Coming, Including Me 😅 | RonMega Highlights #gaming #Shorts",
            "The Moment That Made Me Hit Record 🎮 #ronmegagaming #gamingmoments #Shorts",
            "When the Game Decides to Go Off 🔥 | RonMega Gaming #gaming #clips #Shorts",
            "Can't Script Moments Like This 😤 | RonMega Gaming #gamingclips #Shorts",
            "They Really Thought It Was Over 💀 | RonMega Gaming #gaming #Shorts",
        ],
        "tiktok": [
            "idk what happened but it worked 😭🔥 #gaming #fyp #ronmegagaming",
            "the game said choose violence tonight 😤 #gaming #fyp #gamingclips",
            "okay but who taught me how to do that 💀 #gaming #fyp #ronmega",
            "bro really thought 😭 #gaming #fyp #gamingmoments",
            "this is why I don't quit when I'm down 🔥 #gaming #fyp #ronmegagaming",
            "they had home field advantage and still caught a loss 😅 #gaming #fyp",
        ],
        "facebook": [
            "Some clips you just have to post because keeping them to yourself feels criminal 😂 #RonMegaGaming",
            "Months of gaming for one moment like this. Worth it. 🎮🔥 #RonMegaGaming",
            "I replayed this like 6 times before I believed it happened 😅 #Gaming #RonMegaGaming",
            "The energy in this clip is something else. Watch till the end 🔥 #RonMegaGaming",
            "This one had me out of my chair 😤 drop a 🔥 if you felt that. #RonMegaGaming #Gaming",
            "Not every game goes like this but when it does... you hit record 🎮 #RonMegaGaming",
        ],
    }
}

def get_captions(filename):
    """Returns a dict with platform-specific captions: youtube, tiktok, facebook"""
    fn = filename.lower()
    if any(w in fn for w in ['brawl', 'brawlhalla']):
        pool = CAPTIONS['brawlhalla']
    elif any(w in fn for w in ['warzone', 'cod', 'duty', 'call']):
        pool = CAPTIONS['warzone']
    else:
        pool = CAPTIONS['default']

    return {
        'youtube':  random.choice(pool['youtube']),
        'tiktok':   random.choice(pool['tiktok']),
        'facebook': random.choice(pool['facebook']),
    }

def get_caption(filename):
    """Legacy single-caption fallback — returns YouTube caption"""
    return get_captions(filename)['youtube']

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {'processed': [], 'history': []}

def save_state(state):
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def get_video_info(filepath):
    cmd = [FFPROBE, '-v', 'quiet', '-print_format', 'json', '-show_streams', filepath]
    result = subprocess.run(cmd, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        vs = next((s for s in data['streams'] if s['codec_type'] == 'video'), None)
        if vs:
            return {
                'width': int(vs.get('width', 1920)),
                'height': int(vs.get('height', 1080)),
                'duration': float(vs.get('duration', 60))
            }
    except:
        pass
    return {'width': 1920, 'height': 1080, 'duration': 60}

def process_clip(filepath, max_duration=58):
    """Convert clip to 9:16 vertical Shorts format with blur border effect."""
    info = get_video_info(filepath)
    name = Path(filepath).stem
    output = f'{PROCESSED}/{name}_shorts.mp4'

    # If already processed, skip
    if os.path.exists(output):
        print(f'Already processed: {output}')
        return output

    duration = min(info['duration'], max_duration)

    # Blur border effect:
    # - Background layer: scale to fill 1080x1920, crop, heavy blur
    # - Foreground layer: scale to fit width, overlay centered
    # Matches the TikTok/Shorts blurred border look
    vf = (
        '[0:v]scale=1080:1920:force_original_aspect_ratio=increase,'
        'crop=1080:1920,boxblur=40:40[bg];'
        '[0:v]scale=1080:-2[fg];'
        '[bg][fg]overlay=(W-w)/2:(H-h)/2[out]'
    )

    cmd = [
        FFMPEG, '-y', '-i', filepath,
        '-t', str(duration),
        '-filter_complex', vf,
        '-map', '[out]', '-map', '0:a',
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
        '-c:a', 'aac', '-b:a', '128k',
        '-movflags', '+faststart',
        output
    ]
    print(f'Processing {Path(filepath).name} → {Path(output).name} (blur border)')
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f'FFmpeg error: {r.stderr[-300:]}')
        return None
    print(f'Processed OK ({os.path.getsize(output) // 1024 // 1024}MB)')
    return output

def post_youtube(video_path, caption):
    """Upload to YouTube Shorts via Data API."""
    try:
        sys.path.insert(0, f'{WORKSPACE}/scripts')
        from yt_upload import upload_video
        vid_id, url = upload_video(video_path, caption, caption)
        print(f'YouTube ✅ {url}')
        return True, url
    except Exception as e:
        print(f'YouTube ❌ {e}')
        return False, None

def post_tiktok(video_path, caption):
    """Upload to TikTok via browser."""
    script = f'{WORKSPACE}/scripts/tiktok_upload.js'
    result = subprocess.run(
        ['node', script, video_path, caption],
        capture_output=True, text=True, timeout=180
    )
    output = result.stdout + result.stderr
    success = 'SUCCESS' in output or 'tiktokstudio/content' in output
    print(f'TikTok {"✅" if success else "❌"} {output.split(chr(10))[-3] if output else ""}')
    return success, None

def post_facebook(video_path, caption):
    """Upload to Facebook feed via browser."""
    script = f'{WORKSPACE}/scripts/fb_upload.js'
    result = subprocess.run(
        ['node', script, video_path, caption],
        capture_output=True, text=True, timeout=180
    )
    output = result.stdout + result.stderr
    success = 'SUCCESS' in output or 'being processed' in output.lower()
    print(f'Facebook Feed {"✅" if success else "❌"}')
    return success, None

def post_facebook_story(video_path):
    """Post to Facebook Stories via browser."""
    script = f'{WORKSPACE}/scripts/fb_story.js'
    result = subprocess.run(
        ['node', script, video_path],
        capture_output=True, text=True, timeout=180
    )
    output = result.stdout + result.stderr
    success = 'SUCCESS' in output or 'story' in output.lower()
    print(f'Facebook Story {"✅" if success else "❌"}')
    return success, None

def post_instagram(video_path, caption):
    """Share to Instagram (Reels) via browser."""
    script = f'{WORKSPACE}/scripts/ig_upload.js'
    result = subprocess.run(
        ['node', script, video_path, caption],
        capture_output=True, text=True, timeout=240
    )
    output = result.stdout + result.stderr
    success = 'SUCCESS' in output or 'shared' in output.lower()
    print(f'Instagram {"✅" if success else "❌"}')
    return success, None

def process_and_post(filepath):
    """Full pipeline: process → post to all platforms."""
    filename = Path(filepath).name
    print(f'\n{"="*50}')
    print(f'📁 {filename}')
    print(f'{"="*50}')

    captions = get_captions(filename)
    print(f'YT caption:  {captions["youtube"][:70]}')
    print(f'TT caption:  {captions["tiktok"][:70]}')
    print(f'FB caption:  {captions["facebook"][:70]}')

    # Process to Shorts format
    processed = process_clip(filepath)
    if not processed:
        return {'file': filename, 'status': 'process_failed', 'ts': datetime.now().isoformat()}

    results = {
        'file': filename,
        'captions': captions,
        'ts': datetime.now().isoformat(),
        'platforms': {}
    }

    # Post to all platforms with platform-specific captions
    # Facebook post includes "Share to Instagram" toggle — no separate IG post needed
    yt_ok, yt_url   = post_youtube(processed, captions['youtube'])
    time.sleep(2)
    tt_ok, _         = post_tiktok(processed, captions['tiktok'])
    time.sleep(2)
    fb_ok, _         = post_facebook(processed, captions['facebook'])  # includes IG share toggle
    time.sleep(3)
    fb_story_ok, _   = post_facebook_story(processed)

    results['platforms'] = {
        'youtube':         'ok' if yt_ok else 'failed',
        'tiktok':          'ok' if tt_ok else 'failed',
        'facebook':        'ok' if fb_ok else 'failed',
        'facebook_story':  'ok' if fb_story_ok else 'failed',
        'instagram':       'via_facebook',
    }
    if yt_url:
        results['youtube_url'] = yt_url

    # Archive original (copy first, then remove source — safe for re-runs)
    archive = f'{PROCESSED}/{filename}'
    if not os.path.exists(archive):
        shutil.copy2(filepath, archive)
        os.remove(filepath)
    print(f'\nArchived → {archive}')

    # Cleanup processed short
    try:
        os.remove(processed)
    except:
        pass

    status_icons = {k: '✅' if v in ('ok','via_facebook') else '❌' for k, v in results['platforms'].items()}
    print(f'\n📊 Results: YT {status_icons["youtube"]}  TT {status_icons["tiktok"]}  FB {status_icons["facebook"]}  FB Story {status_icons["facebook_story"]}  IG via FB {status_icons["instagram"]}')
    return results

def is_used(filepath):
    """Check if a file has already been processed — via .done marker file OR state JSON."""
    done_marker = filepath + '.done'
    if os.path.exists(done_marker):
        return True
    state = load_state()
    return Path(filepath).name in state.get('processed', [])

def mark_used(filepath):
    """Mark a file as used with a .done marker file — survives state resets."""
    done_marker = filepath + '.done'
    with open(done_marker, 'w') as f:
        f.write(datetime.now().isoformat())

def watch_folder():
    state = load_state()
    print(f'👀 Watching {CLIPS_DIR}')
    print('Drop .mp4 / .mov clips in that folder to auto-post.\n')

    while True:
        try:
            files = [f for f in os.listdir(CLIPS_DIR)
                     if Path(f).suffix.lower() in VIDEO_EXTS
                     and not os.path.exists(os.path.join(CLIPS_DIR, f) + '.done')
                     and f not in state.get('processed', [])]

            for filename in files:
                filepath = os.path.join(CLIPS_DIR, filename)
                time.sleep(3)  # Wait for file to finish writing
                if not os.path.exists(filepath):
                    continue
                mark_used(filepath)  # Mark BEFORE posting — prevents double-post if crash
                result = process_and_post(filepath)
                state['processed'].append(filename)
                state['last_run'] = datetime.now().isoformat()
                state.setdefault('history', []).append(result)
                save_state(state)

            time.sleep(15)

        except KeyboardInterrupt:
            print('\nStopped.')
            break
        except Exception as e:
            print(f'Error: {e}')
            time.sleep(30)

def check_pending():
    state = load_state()
    files = [f for f in os.listdir(CLIPS_DIR)
             if Path(f).suffix.lower() in VIDEO_EXTS
             and not os.path.exists(os.path.join(CLIPS_DIR, f) + '.done')
             and f not in state.get('processed', [])]
    if files:
        print(f'Found {len(files)} pending clip(s): {files}')
        for f in files:
            filepath = os.path.join(CLIPS_DIR, f)
            mark_used(filepath)  # Mark BEFORE posting
            result = process_and_post(filepath)
            state['processed'].append(f)
            state.setdefault('history', []).append(result)
            save_state(state)
    else:
        print('No new clips.')

if __name__ == '__main__':
    if '--watch' in sys.argv:
        watch_folder()
    elif '--file' in sys.argv:
        idx = sys.argv.index('--file')
        filepath = sys.argv[idx + 1]
        if is_used(filepath):
            print(f'⚠️  Already posted: {Path(filepath).name} — skipping.')
        else:
            mark_used(filepath)
            result = process_and_post(filepath)
            print(json.dumps(result, indent=2))
    elif '--check' in sys.argv:
        check_pending()
    else:
        print(__doc__)
