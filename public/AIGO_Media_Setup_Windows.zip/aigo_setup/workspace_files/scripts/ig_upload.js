/**
 * RonMega Gaming — Instagram Reels Uploader
 * Posts video as an Instagram Reel
 * 
 * First run: node ig_upload.js --setup   (logs in and saves cookies)
 * Normal:    node ig_upload.js <video_path> <caption>
 */
const { chromium } = require('/Users/ronniemack/.npm/_npx/e41f203b7505f1fb/node_modules/playwright');
const fs = require('fs');
const path = require('path');

const COOKIES_FILE = '/Users/ronniemack/.openclaw/workspace/config/ig_cookies.json';
const VIDEO_PATH = process.argv[2];
const CAPTION = process.argv[3] || 'When the game gets real 😤 #ronmegagaming #gaming #gamer #reels';

async function setup() {
  console.log('=== Instagram Setup Mode ===');
  console.log('A browser window will open. Log into Instagram, then press Enter here.');
  
  const browser = await chromium.launch({ headless: false, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 }
  });
  const page = await ctx.newPage();
  await page.goto('https://www.instagram.com/accounts/login/');
  
  console.log('Log in to Instagram in the browser window, then press Enter...');
  await new Promise(resolve => {
    process.stdin.resume();
    process.stdin.once('data', resolve);
  });

  const cookies = await ctx.cookies();
  fs.writeFileSync(COOKIES_FILE, JSON.stringify(cookies, null, 2));
  console.log(`✅ Cookies saved to ${COOKIES_FILE}`);
  await browser.close();
  process.exit(0);
}

async function uploadReel() {
  if (!fs.existsSync(COOKIES_FILE)) {
    console.error('No Instagram cookies found. Run: node ig_upload.js --setup');
    process.exit(1);
  }
  if (!VIDEO_PATH || !fs.existsSync(VIDEO_PATH)) {
    console.error('Video file not found:', VIDEO_PATH);
    process.exit(1);
  }

  const rawCookies = JSON.parse(fs.readFileSync(COOKIES_FILE));
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 }
  });
  await ctx.addCookies(rawCookies);
  const page = await ctx.newPage();

  console.log('Loading Instagram...');
  await page.goto('https://www.instagram.com/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(4000);

  // Click the "+" Create button
  console.log('Opening create dialog...');
  const createClicked = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('a, [role="button"], svg'));
    const btn = els.find(e => {
      const label = e.getAttribute('aria-label') || '';
      return label.toLowerCase() === 'new post' || label.toLowerCase() === 'create';
    });
    if (btn) { btn.click(); return true; }
    // Try by href
    const links = Array.from(document.querySelectorAll('a[href*="create"]'));
    if (links[0]) { links[0].click(); return true; }
    return false;
  });

  await page.waitForTimeout(3000);
  await page.screenshot({ path: '/Users/ronniemack/.openclaw/workspace/config/ig_step1.png' });

  // Select from computer / file input
  const fileInput = await page.$('input[type="file"]');
  if (fileInput) {
    await fileInput.setInputFiles(VIDEO_PATH);
    console.log('Video file selected, waiting for upload...');
  } else {
    // Try clicking "Select from computer"
    const selectClicked = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('[role="button"], button'));
      const btn = btns.find(b => (b.innerText || '').toLowerCase().includes('select from'));
      if (btn) { btn.click(); return true; }
      return false;
    });
    await page.waitForTimeout(2000);
    const fi = await page.$('input[type="file"]');
    if (fi) await fi.setInputFiles(VIDEO_PATH);
  }

  await page.waitForTimeout(8000);
  await page.screenshot({ path: '/Users/ronniemack/.openclaw/workspace/config/ig_step2.png' });

  // Click through any format/crop dialogs → "OK" or "Next"
  for (let i = 0; i < 6; i++) {
    const result = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('[role="button"], button'));
      // Priority: OK > Next > Share
      const ok = btns.find(b => (b.innerText || '').trim() === 'OK');
      if (ok) { ok.click(); return 'ok'; }
      const next = btns.find(b => (b.innerText || '').trim() === 'Next');
      if (next) { next.click(); return 'next'; }
      const share = btns.find(b => (b.innerText || '').trim() === 'Share');
      if (share) { share.click(); return 'share'; }
      return 'none';
    });
    console.log(`Step ${i+1}: ${result}`);
    if (result === 'share') {
      console.log('Instagram: Share clicked! SUCCESS');
      await page.waitForTimeout(8000);
      break;
    }
    await page.waitForTimeout(3500);
    await page.screenshot({ path: `/Users/ronniemack/.openclaw/workspace/config/ig_step${i+3}.png` });
  }

  // Add caption if we're on the caption step
  try {
    const captionBox = await page.$('textarea, [contenteditable="true"][aria-label*="caption"], [contenteditable="true"][aria-label*="Caption"]');
    if (captionBox) {
      await captionBox.click();
      await page.keyboard.type(CAPTION, { delay: 20 });
      console.log('Caption added');
      await page.waitForTimeout(1500);

      // Click Share
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('[role="button"], button'));
        const share = btns.find(b => (b.innerText || '').trim() === 'Share');
        if (share) share.click();
      });
      console.log('Instagram: Final share! SUCCESS');
      await page.waitForTimeout(8000);
    }
  } catch(e) {
    console.log('Caption step skipped:', e.message);
  }

  await page.screenshot({ path: '/Users/ronniemack/.openclaw/workspace/config/ig_final.png' });
  await browser.close();
}

if (process.argv[2] === '--setup') {
  setup().catch(e => console.error('Setup error:', e.message));
} else {
  uploadReel().catch(e => console.error('FATAL:', e.message));
}
