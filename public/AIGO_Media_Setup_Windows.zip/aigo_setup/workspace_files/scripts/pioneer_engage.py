#!/usr/bin/env python3
"""
Pioneer Cache Twitter Engagement — AI-powered, human-sounding replies.
Reads the full post, comprehends it, responds specifically to what was said.
No pools. No patterns. No repeating. Real conversation.
"""

import sys, os, random, json, hashlib
from playwright.sync_api import sync_playwright
import anthropic

# Load API key from config if not in environment
_key_file = '/Users/ronniemack/.openclaw/workspace/config/api_keys.json'
if not os.environ.get('ANTHROPIC_API_KEY') and os.path.exists(_key_file):
    with open(_key_file) as f:
        os.environ['ANTHROPIC_API_KEY'] = json.load(f)['anthropic']

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
USED_RESPONSES_FILE = f'{WORKSPACE}/memory/pioneer_used_responses.json'

def load_used():
    if os.path.exists(USED_RESPONSES_FILE):
        with open(USED_RESPONSES_FILE) as f:
            return json.load(f)
    return []

def save_used(used_list):
    with open(USED_RESPONSES_FILE, 'w') as f:
        json.dump(used_list[-500:], f)

def fingerprint(text):
    return hashlib.md5(text.strip().lower().encode()).hexdigest()

def generate_comment(tweet_text):
    client = anthropic.Anthropic()
    
    system = """You are Ron, someone who built The Pioneer Cache — a $5.99 offline survival guide (thepioneercache.com).
You're a real member of the prepper, homesteader, and off-grid community.

CRITICAL RULES — non-negotiable:
- Read the ENTIRE post. Understand the FULL situation — not just the topic, the whole human context.
- EXAMPLE OF WHAT NEVER TO DO: Someone says "Lost my entire garden to flooding. We needed that food." A bad reply is "Every setback is a lesson — keep prepping!" That reply saw "garden" and "prepping" and missed the loss, the food insecurity, the real hardship. That is unacceptable.
- WHAT TO DO INSTEAD: "That's a real gut punch — losing a garden you counted on is not just about plants. Hope you've got backup stores and that things dry out soon." You address WHAT THEY ACTUALLY SAID.
- If someone lost something, is struggling, or shares hardship → empathy FIRST, always. No toxic positivity.
- If someone shares a win → celebrate the SPECIFIC thing they did, not a generic "nice work"
- If someone asks a question → actually try to answer it with real knowledge
- NEVER latch onto a keyword and miss the human situation behind it
- NEVER paste motivational quotes on real pain
- Sound like a real person in this community who was genuinely listening
- 1-3 sentences. Conversational. No corporate or brand-speak.
- 12% of the time mention thepioneercache.com ONLY when it genuinely and naturally fits
- NEVER start with "I", "Great", "Amazing", "Awesome", "Love this", "This is so"
- Every reply must be unique and specific to this exact post"""

    prompt = f"""Tweet from the prepper/survival/homesteading community:

"{tweet_text}"

Read every word. Understand the full situation this person is describing — not just the topic, but what they're actually going through. Write a genuine, specific reply that addresses the WHOLE thing. If there's hardship or loss in there, acknowledge that first."""

    response = anthropic.Anthropic().messages.create(
        model="claude-haiku-4-5",
        max_tokens=150,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text.strip()

SEARCH_QUERIES = [
    "prepper tips 2026",
    "survival skills homestead",
    "off grid living",
    "emergency preparedness",
    "SHTF prep",
    "bug out bag 2026",
    "water storage survival",
    "foraging wild edibles",
    "grid down living",
    "homesteading life",
    "food storage long term",
    "off grid power solar",
    "prepper community",
    "self sufficient living",
]

def engage(max_comments=4):
    query = random.choice(SEARCH_QUERIES)
    print(f"Searching: {query}")
    
    used = load_used()
    commented = 0

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=f'{WORKSPACE}/config/browser_session',
            headless=True,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled'],
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = browser.new_page()

        search_url = f"https://x.com/search?q={query.replace(' ', '%20')}&f=live"
        page.goto(search_url)
        page.wait_for_timeout(5000)

        articles = page.query_selector_all('article[data-testid="tweet"]')

        for article in articles[:30]:
            if commented >= max_comments:
                break
            try:
                tweet_el = article.query_selector('[data-testid="tweetText"]')
                if not tweet_el:
                    continue
                tweet_text = tweet_el.inner_text().strip()

                if 'thepioneercache' in tweet_text.lower() or len(tweet_text) < 30:
                    continue

                reply_btn = article.query_selector('[data-testid="reply"]')
                if not reply_btn:
                    continue

                print(f"\nReading: {tweet_text[:80]}...")
                comment = generate_comment(tweet_text)

                fp = fingerprint(comment)
                if fp in used:
                    print("  (regenerating — too similar to past comment)")
                    comment = generate_comment(tweet_text)
                    fp = fingerprint(comment)

                print(f"  Replying: {comment[:80]}...")

                reply_btn.click()
                page.wait_for_timeout(2000)
                reply_box = page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=5000)
                reply_box.click()
                page.wait_for_timeout(300)
                page.keyboard.type(comment, delay=40)
                page.wait_for_timeout(1000)

                page.evaluate("""
                    () => {
                        const btn = document.querySelector('[data-testid="tweetButton"]');
                        if (!btn) return;
                        const rect = btn.getBoundingClientRect();
                        btn.dispatchEvent(new MouseEvent('click', {
                            bubbles: true, cancelable: true, view: window,
                            clientX: rect.left + rect.width/2,
                            clientY: rect.top + rect.height/2
                        }));
                    }
                """)
                page.wait_for_timeout(3000)
                used.append(fp)
                save_used(used)
                commented += 1

                try:
                    page.keyboard.press('Escape')
                    page.wait_for_timeout(1000)
                except:
                    pass

            except Exception as e:
                print(f"  Skipped: {str(e)[:60]}")
                continue

        print(f"\nDone. Posted {commented} comments.")
        browser.close()

if __name__ == "__main__":
    max_c = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    engage(max_c)
