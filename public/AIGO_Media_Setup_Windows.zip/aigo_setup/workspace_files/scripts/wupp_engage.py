#!/usr/bin/env python3
"""
WUPP Twitter Engagement — AI-powered, human-sounding replies.
Reads the FULL tweet, comprehends it, generates a response that actually fits.
No pools. No keyword matching. No repeating. Real conversation.
"""

import sys, os, random, json, hashlib
from datetime import datetime
from playwright.sync_api import sync_playwright
import anthropic

# Load API key from config if not in environment
_key_file = '/Users/ronniemack/.openclaw/workspace/config/api_keys.json'
if not os.environ.get('ANTHROPIC_API_KEY') and os.path.exists(_key_file):
    with open(_key_file) as f:
        os.environ['ANTHROPIC_API_KEY'] = json.load(f)['anthropic']

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
USED_RESPONSES_FILE = f'{WORKSPACE}/memory/wupp_used_responses.json'

# Load used responses to prevent ANY repetition
def load_used():
    if os.path.exists(USED_RESPONSES_FILE):
        with open(USED_RESPONSES_FILE) as f:
            return json.load(f)
    return []

def save_used(used_list):
    # Keep last 500 to avoid infinite growth
    with open(USED_RESPONSES_FILE, 'w') as f:
        json.dump(used_list[-500:], f)

def fingerprint(text):
    return hashlib.md5(text.strip().lower().encode()).hexdigest()

def generate_comment(tweet_text, context="wupp"):
    """Use Claude to generate a genuine, specific reply to this exact tweet."""
    client = anthropic.Anthropic()
    
    if context == "wupp":
        system = """You are Ron, a crypto builder who created WUPP coin on Solana.
You are a real person. You READ and COMPREHEND every word before responding.

CRITICAL RULES — read carefully:
- Read the ENTIRE post. Understand the FULL situation, not just a keyword you spotted.
- EXAMPLE OF WHAT NEVER TO DO: Someone says "I sold Bitcoin to pay for my mother's funeral." A bad reply is "Only those who hold will rule." That reply latched onto "sold Bitcoin" and ignored the funeral, the grief, the human. That is tone-deaf and unacceptable.
- WHAT TO DO INSTEAD: Acknowledge the full context. "Sorry for your loss. Family comes first — no Bitcoin is worth more than that." Lead with the human truth.
- If a post has emotional weight (grief, loss, hardship, struggle) → lead with empathy FIRST, always
- If it's a win → celebrate the SPECIFIC win they described, not a generic "let's go"
- If it's frustration or venting → validate what they're specifically frustrated about
- NEVER latch onto one word and miss the whole sentence
- NEVER paste motivational one-liners on top of someone's real pain
- Sound like a real person who read every single word and understood it
- Keep it 1-3 sentences. Conversational. Like texting a friend.
- Occasionally (15% of the time) naturally mention wuppcoin.io — ONLY when it genuinely fits
- NEVER start with "I", "Great", "Amazing", "Awesome", "Love this", "Wow"
- NEVER use "diamond hands", "only the strong survive" or any crypto cliché unless it truly fits"""

        prompt = f"""Here is a tweet someone posted:

"{tweet_text}"

Read every word. Understand the full situation — not just the topic, but what this person is actually going through or saying. Then write a genuine, specific reply that responds to the WHOLE post. If there is any emotional weight, address it first."""

    else:  # pioneer cache / prepper context
        system = """You are Ron, someone who built The Pioneer Cache — an offline survival guide.
You genuinely care about this community and the people in it.

CRITICAL RULES:
- Read the ENTIRE post. Understand the full situation before replying.
- NEVER latch onto a keyword and miss the actual point of the post.
- If someone is in a hard situation → acknowledge THEIR specific situation with empathy first
- If someone is celebrating → celebrate what THEY specifically did
- NEVER paste generic preparedness quotes on top of someone's real struggle
- Sound like a real human who read every word
- 1-3 sentences max. Real and conversational.
- 12% of the time mention thepioneercache.com only when it genuinely fits the context
- NEVER start with "I", "Great", "Amazing", "Awesome"."""

        prompt = f"""Here is a tweet someone posted in the prepper/survival/homesteading space:

"{tweet_text}"

Read every word. Understand what this person is actually saying or going through. Write a genuine reply that responds to the WHOLE situation, not just the topic. If there's emotional weight, lead with that."""

    response = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=150,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text.strip()

SEARCH_QUERIES_WUPP = [
    "Solana memecoin 2026",
    "building on Solana",
    "crypto community grind",
    "Solana defi launch",
    "meme coin launch 2026",
    "fair launch crypto",
    "solana community token",
    "crypto hustle mindset",
    "web3 grind",
    "Raydium liquidity",
]

def engage(max_comments=5, context="wupp"):
    query = random.choice(SEARCH_QUERIES_WUPP)
    print(f"Searching: {query}")
    
    used = load_used()
    commented = 0

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=f'{WORKSPACE}/config/browser_session',
            headless=True,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled'],
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = browser.new_page()

        search_url = f"https://x.com/search?q={query.replace(' ', '%20')}&f=live"
        page.goto(search_url)
        page.wait_for_timeout(5000)

        articles = page.query_selector_all('article[data-testid="tweet"]')

        for article in articles[:30]:
            if commented >= max_comments:
                break
            try:
                tweet_el = article.query_selector('[data-testid="tweetText"]')
                if not tweet_el:
                    continue
                tweet_text = tweet_el.inner_text().strip()

                # Skip our own posts, very short posts, retweets
                if any(x in tweet_text.lower() for x in ['wuppcryptocoin', 'thepioneercache']):
                    continue
                if len(tweet_text) < 30:
                    continue

                reply_btn = article.query_selector('[data-testid="reply"]')
                if not reply_btn:
                    continue

                # Generate AI comment — actually reads the tweet
                print(f"\nReading: {tweet_text[:80]}...")
                comment = generate_comment(tweet_text, context)
                
                # Check we haven't said something like this before
                fp = fingerprint(comment)
                if fp in used:
                    print("  (regenerating — too similar to past comment)")
                    comment = generate_comment(tweet_text, context)
                    fp = fingerprint(comment)

                print(f"  Replying: {comment[:80]}...")

                # Post the reply
                reply_btn.click()
                page.wait_for_timeout(2000)
                reply_box = page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=5000)
                reply_box.click()
                page.wait_for_timeout(300)
                page.keyboard.type(comment, delay=40)
                page.wait_for_timeout(2000)

                # JS click bypasses overlay divs that intercept pointer events
                page.evaluate("""() => {
                    const btn = document.querySelector('[data-testid="tweetButtonInline"]')
                             || document.querySelector('[data-testid="tweetButton"]');
                    if (btn) btn.click();
                }""")
                page.wait_for_timeout(3000)
                used.append(fp)
                save_used(used)
                commented += 1

                try:
                    page.keyboard.press('Escape')
                    page.wait_for_timeout(1000)
                except:
                    pass

            except Exception as e:
                print(f"  Skipped: {str(e)[:60]}")
                continue

        print(f"\nDone. Posted {commented} comments.")
        browser.close()

if __name__ == "__main__":
    max_c = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    ctx = sys.argv[2] if len(sys.argv) > 2 else "wupp"
    engage(max_c, ctx)
