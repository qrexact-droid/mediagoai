#!/usr/bin/env python3
"""
WUPP Twitter Reply Monitor — AI-powered, human-sounding replies.
Reads each mention fully, comprehends it, responds specifically.
No pools. No patterns. No repeating. Real conversation.
"""

import sys, os, random, json, hashlib
from playwright.sync_api import sync_playwright
import anthropic

# Load API key from config if not in environment
_key_file = '/Users/ronniemack/.openclaw/workspace/config/api_keys.json'
if not os.environ.get('ANTHROPIC_API_KEY') and os.path.exists(_key_file):
    with open(_key_file) as f:
        os.environ['ANTHROPIC_API_KEY'] = json.load(f)['anthropic']

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
USED_RESPONSES_FILE = f'{WORKSPACE}/memory/wupp_used_responses.json'

def load_used():
    if os.path.exists(USED_RESPONSES_FILE):
        with open(USED_RESPONSES_FILE) as f:
            return json.load(f)
    return []

def save_used(used_list):
    with open(USED_RESPONSES_FILE, 'w') as f:
        json.dump(used_list[-500:], f)

def fingerprint(text):
    return hashlib.md5(text.strip().lower().encode()).hexdigest()

def generate_reply(tweet_text, is_mention=True):
    """Generate a reply that actually comprehends what was said."""
    client = anthropic.Anthropic()

    system = """You are Ron, the creator of WUPP coin on Solana (wuppcoin.io).
You are a real person. You read and understand every single word before you respond.

CRITICAL RULES — non-negotiable:
- Read the ENTIRE message. Understand the FULL situation — not just the topic, but what this person is going through.
- EXAMPLE OF WHAT NEVER TO DO: Someone says "I sold my Bitcoin to pay for my mother's funeral." A bad reply is "Only those who hold will rule." That reply saw "sold Bitcoin" and missed the funeral, the grief, the whole human situation. That is tone-deaf and unacceptable.
- WHAT TO DO: "Sorry for your loss. Family comes first — no amount of crypto is worth more than that." You address the WHOLE situation.
- If there is ANY emotional weight (loss, grief, hardship, struggle, failure) → empathy comes FIRST, always, no exceptions
- If someone sold or lost crypto due to hardship → NEVER lecture them about holding. Acknowledge their situation.
- If someone is skeptical → address their SPECIFIC concern, not a canned "we're legit" response
- If someone asks a question → actually answer it specifically
- If someone is winning → celebrate the SPECIFIC thing they did
- NEVER paste motivational clichés on top of someone's real pain
- Sound like a real human who read every word, not a community manager bot
- 1-3 sentences max. Conversational. Real.
- Don't start with "I", "Great", "Amazing", "Awesome", "Wow", "Love"
- Mention wuppcoin.io only when it genuinely fits — never forced
- Every reply must be unique to this exact moment and this exact person"""

    prompt = f"""Someone {"mentioned or replied to" if is_mention else "posted"} the WUPP account with this message:

"{tweet_text}"

Read every word carefully. Understand what this person is actually going through or saying — the full situation, not just the surface topic. Then write a genuine reply that responds to the WHOLE context. If there is any emotional weight or hardship, acknowledge that first."""

    response = client.messages.create(
        model="claude-haiku-4-5",
        max_tokens=150,
        system=system,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text.strip()

def check_and_reply(max_replies=5):
    used = load_used()
    replied = 0

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=f'{WORKSPACE}/config/browser_session',
            headless=True,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled'],
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = browser.new_page()

        page.goto("https://x.com/notifications/mentions")
        page.wait_for_timeout(5000)

        articles = page.query_selector_all('article[data-testid="tweet"]')

        for article in articles[:15]:
            if replied >= max_replies:
                break
            try:
                tweet_el = article.query_selector('[data-testid="tweetText"]')
                if not tweet_el:
                    continue
                tweet_text = tweet_el.inner_text().strip()

                # Skip our own posts
                author_el = article.query_selector('[data-testid="User-Name"]')
                if author_el and "WUPPCryptoCoin" in author_el.inner_text():
                    continue

                if len(tweet_text) < 10:
                    continue

                reply_btn = article.query_selector('[data-testid="reply"]')
                if not reply_btn:
                    continue

                print(f"\nReading mention: {tweet_text[:80]}...")
                response = generate_reply(tweet_text, is_mention=True)

                fp = fingerprint(response)
                if fp in used:
                    print("  (regenerating — too similar to past reply)")
                    response = generate_reply(tweet_text, is_mention=True)
                    fp = fingerprint(response)

                print(f"  Replying: {response[:80]}...")

                reply_btn.click()
                page.wait_for_timeout(2000)
                reply_box = page.wait_for_selector('[data-testid="tweetTextarea_0"]', timeout=5000)
                reply_box.click()
                page.wait_for_timeout(300)
                page.keyboard.type(response, delay=40)
                page.wait_for_timeout(1000)

                page.evaluate("""
                    () => {
                        const btn = document.querySelector('[data-testid="tweetButton"]');
                        if (!btn) return;
                        const rect = btn.getBoundingClientRect();
                        btn.dispatchEvent(new MouseEvent('click', {
                            bubbles: true, cancelable: true, view: window,
                            clientX: rect.left + rect.width/2,
                            clientY: rect.top + rect.height/2
                        }));
                    }
                """)
                page.wait_for_timeout(3000)
                used.append(fp)
                save_used(used)
                replied += 1
                print(f"  Done ({replied}/{max_replies})")

                try:
                    page.keyboard.press('Escape')
                    page.wait_for_timeout(1000)
                except:
                    pass

            except Exception as e:
                print(f"  Skipped: {str(e)[:60]}")
                continue

        print(f"\nDone. Replied to {replied} mentions.")
        browser.close()

if __name__ == "__main__":
    max_r = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    check_and_reply(max_r)
