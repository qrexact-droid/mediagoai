#!/usr/bin/env python3
"""
Instagram login — saves session cookies for ig_upload.js
"""
import json, time, os
from playwright.sync_api import sync_playwright

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
COOKIES_FILE = f'{WORKSPACE}/config/ig_cookies.json'
PHONE = '7029044661'
PASSWORD = 'Lkqyysa1227!'

with sync_playwright() as p:
    browser = p.chromium.launch_persistent_context(
        user_data_dir=f'{WORKSPACE}/config/ig_session',
        headless=True,
        args=['--no-sandbox'],
        user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    )
    page = browser.new_page()
    print('Loading Instagram login...')
    page.goto('https://www.instagram.com/accounts/login/', wait_until='domcontentloaded')
    page.wait_for_timeout(6000)
    page.screenshot(path=f'{WORKSPACE}/config/ig_login_step1.png')
    print(f'URL: {page.url}')
    print(f'Title: {page.title()}')

    # Dismiss any cookie/consent dialog first
    for _ in range(3):
        dismissed = page.evaluate("""() => {
            const btns = Array.from(document.querySelectorAll('[role="button"], button'));
            const allow = btns.find(b => {
                const t = (b.innerText||'').toLowerCase();
                return t.includes('allow') || t.includes('accept') || t.includes('decline') || t.includes('not now') || t.includes('only allow');
            });
            if (allow) { allow.click(); return allow.innerText; }
            return null;
        }""")
        if dismissed:
            print(f'Dismissed dialog: {dismissed}')
            page.wait_for_timeout(2000)
        else:
            break

    page.wait_for_timeout(2000)
    page.screenshot(path=f'{WORKSPACE}/config/ig_login_step2.png')

    # Try to find login fields
    try:
        # Try multiple selectors for the username/phone field
        user_input = page.wait_for_selector(
            'input[name="username"], input[aria-label*="Mobile"], input[aria-label*="phone"], input[type="text"]',
            timeout=8000
        )
        user_input.click()
        page.keyboard.type(PHONE, delay=50)
        page.wait_for_timeout(500)

        pass_input = page.wait_for_selector('input[name="password"], input[type="password"]', timeout=5000)
        pass_input.click()
        page.keyboard.type(PASSWORD, delay=50)
        page.wait_for_timeout(500)

        page.keyboard.press('Enter')
        print('Logging in...')
        page.wait_for_timeout(10000)
        page.screenshot(path=f'{WORKSPACE}/config/ig_login_step3.png')

        # Handle popups
        for _ in range(3):
            dismissed = page.evaluate("""() => {
                const btns = Array.from(document.querySelectorAll('[role="button"], button'));
                const notnow = btns.find(b => (b.innerText||'').toLowerCase().includes('not now'));
                if (notnow) { notnow.click(); return true; }
                return false;
            }""")
            if dismissed:
                page.wait_for_timeout(2000)
            else:
                break

        cookies = browser.cookies()
        with open(COOKIES_FILE, 'w') as f:
            json.dump(cookies, f, indent=2)
        print(f'✅ Saved {len(cookies)} cookies')

    except Exception as e:
        print(f'Error: {e}')
        print('Check screenshots in config/ folder')

    browser.close()
