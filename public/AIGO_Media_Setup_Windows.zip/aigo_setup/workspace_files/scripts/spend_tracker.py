#!/usr/bin/env python3
"""
OpenClaw Spend Tracker
Reads session data and outputs current spend stats as JSON.
"""

import json
import sys
import os
from pathlib import Path

# Anthropic claude-sonnet-4-6 pricing per million tokens
PRICING = {
    "input":       3.00,   # $3/M input tokens
    "output":      15.00,  # $15/M output tokens
    "cache_read":  0.30,   # $0.30/M cache read
    "cache_write": 3.75,   # $3.75/M cache write
}

# Monthly budget (auto top-off target)
MONTHLY_BUDGET = 200.00  # $200/mo — Ron's stated OpenClaw cost

def get_sessions_path():
    home = Path.home()
    return home / ".openclaw" / "agents" / "main" / "sessions" / "sessions.json"

def calculate_spend():
    path = get_sessions_path()
    if not path.exists():
        return {"error": "sessions.json not found", "cost": 0, "pct": 0}

    with open(path) as f:
        data = json.load(f)

    total_input = 0
    total_output = 0
    total_cache_read = 0
    total_cache_write = 0
    session_count = 0

    for key, session in data.items():
        if not isinstance(session, dict):
            continue
        total_input      += session.get("inputTokens", 0) or 0
        total_output     += session.get("outputTokens", 0) or 0
        total_cache_read += session.get("cacheRead", 0) or 0
        total_cache_write+= session.get("cacheWrite", 0) or 0
        session_count    += 1

    cost = (
        total_input       / 1e6 * PRICING["input"] +
        total_output      / 1e6 * PRICING["output"] +
        total_cache_read  / 1e6 * PRICING["cache_read"] +
        total_cache_write / 1e6 * PRICING["cache_write"]
    )

    pct = min(100, (cost / MONTHLY_BUDGET) * 100)

    # Determine status
    if pct >= 80:
        status = "red"
        label = "LOW — Running hot!"
    elif pct >= 50:
        status = "yellow"
        label = "MID — On track"
    else:
        status = "green"
        label = "GOOD — Budget healthy"

    return {
        "cost": round(cost, 4),
        "budget": MONTHLY_BUDGET,
        "pct": round(pct, 2),
        "status": status,
        "label": label,
        "tokens": {
            "input": total_input,
            "output": total_output,
            "cache_read": total_cache_read,
            "cache_write": total_cache_write,
        },
        "sessions": session_count,
    }

if __name__ == "__main__":
    result = calculate_spend()
    print(json.dumps(result, indent=2))
