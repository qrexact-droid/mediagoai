#!/usr/bin/env python3
"""
Updates budget_tracker.json with estimated monthly spend.
Called nightly by the maintenance cron.
Uses session logs to estimate token costs.
Anthropic claude-sonnet-4-6 pricing:
  Input:  $3.00 per 1M tokens (cache miss), $0.30 per 1M (cache hit)
  Output: $15.00 per 1M tokens
"""
import json, os, glob, re
from datetime import datetime

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
BUDGET_FILE = f'{WORKSPACE}/budget_tracker.json'
SESSIONS_DIR = os.path.expanduser('~/.openclaw/agents/main/sessions')

# Pricing (per token)
INPUT_COST    = 3.00 / 1_000_000
CACHE_COST    = 0.30 / 1_000_000
OUTPUT_COST   = 15.00 / 1_000_000

def load_budget():
    if os.path.exists(BUDGET_FILE):
        with open(BUDGET_FILE) as f:
            return json.load(f)
    return {
        'monthly_budget': 15.00,
        'warning_at': 10.00,
        'month': datetime.now().strftime('%Y-%m'),
        'total_spent': 0.00,
        'last_updated': datetime.now().strftime('%Y-%m-%d'),
        'sessions': []
    }

def save_budget(data):
    with open(BUDGET_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def estimate_costs():
    """Scan session JSONL files and total up token costs for this month."""
    current_month = datetime.now().strftime('%Y-%m')
    total_cost = 0.0
    session_costs = []

    if not os.path.exists(SESSIONS_DIR):
        return 0.0, []

    for filepath in glob.glob(f'{SESSIONS_DIR}/*.jsonl'):
        try:
            file_cost = 0.0
            with open(filepath) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        # Check timestamp is this month
                        ts = msg.get('timestamp', 0)
                        if ts:
                            dt = datetime.fromtimestamp(ts / 1000)
                            if dt.strftime('%Y-%m') != current_month:
                                continue
                        usage = msg.get('usage', {})
                        if not usage:
                            continue
                        input_tokens  = usage.get('input', 0)
                        output_tokens = usage.get('output', 0)
                        cache_read    = usage.get('cacheRead', 0)
                        cache_write   = usage.get('cacheWrite', 0)
                        # Cost: regular input + cache hits (cheaper) + output
                        new_input = max(input_tokens - cache_read, 0)
                        cost = (new_input * INPUT_COST) + (cache_read * CACHE_COST) + (output_tokens * OUTPUT_COST)
                        file_cost += cost
                    except:
                        continue
            if file_cost > 0:
                total_cost += file_cost
                session_costs.append({
                    'file': os.path.basename(filepath),
                    'cost': round(file_cost, 4)
                })
        except:
            continue

    return round(total_cost, 4), session_costs

def main():
    data = load_budget()
    current_month = datetime.now().strftime('%Y-%m')

    # Reset if new month
    if data.get('month') != current_month:
        data['month'] = current_month
        data['total_spent'] = 0.00
        data['sessions'] = []
        print(f'New month — reset budget tracker')

    total, sessions = estimate_costs()
    data['total_spent'] = total
    data['last_updated'] = datetime.now().strftime('%Y-%m-%d %H:%M')
    data['sessions'] = sessions[:20]  # Keep last 20

    save_budget(data)

    budget = data['monthly_budget']
    warning = data['warning_at']
    remaining = budget - total
    pct = (total / budget) * 100

    status = '🟢 GREEN' if total < warning else ('🟡 YELLOW' if total < budget else '🔴 RED')
    print(f'Budget Status: {status}')
    print(f'  Spent:     ${total:.4f}')
    print(f'  Budget:    ${budget:.2f}')
    print(f'  Remaining: ${remaining:.4f} ({100-pct:.1f}% left)')

if __name__ == '__main__':
    main()
