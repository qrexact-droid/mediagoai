#!/usr/bin/env python3
"""
YouTube Upload via API — RonMega Gaming
Uploads a video as a YouTube Short (vertical, <60s).
Usage: python3 yt_upload.py --file video.mp4 --title "My title" --desc "description"
"""

import os, sys, json, argparse
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES     = ['https://www.googleapis.com/auth/youtube.upload',
              'https://www.googleapis.com/auth/youtube']
TOKEN_FILE = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_token.json'
CREDS_FILE = '/Users/ronniemack/.openclaw/workspace/config/yt_oauth_creds.json'

def get_credentials():
    creds = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            with open(TOKEN_FILE, 'w') as f:
                f.write(creds.to_json())
        else:
            raise Exception('Token expired or missing. Run yt_auth.py again.')
    return creds

def upload_video(filepath, title, description, tags=None, category_id='20'):
    """
    Upload video to YouTube.
    category_id 20 = Gaming
    Returns video ID on success.
    """
    creds = get_credentials()
    youtube = build('youtube', 'v3', credentials=creds)

    if tags is None:
        tags = ['ronmegagaming', 'gaming', 'gamer', 'clips', 'Shorts']

    body = {
        'snippet': {
            'title': title[:100],
            'description': description[:5000],
            'tags': tags,
            'categoryId': category_id,
        },
        'status': {
            'privacyStatus': 'public',
            'selfDeclaredMadeForKids': False,
        }
    }

    media = MediaFileUpload(
        filepath,
        mimetype='video/mp4',
        resumable=True,
        chunksize=1024*1024*5  # 5MB chunks
    )

    print(f'Uploading: {os.path.basename(filepath)}')
    print(f'Title: {title}')

    request = youtube.videos().insert(
        part='snippet,status',
        body=body,
        media_body=media
    )

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            pct = int(status.progress() * 100)
            print(f'  Upload progress: {pct}%')

    video_id = response.get('id', '')
    video_url = f'https://youtube.com/shorts/{video_id}'
    print(f'Upload complete! {video_url}')
    return video_id, video_url

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--file', required=True)
    parser.add_argument('--title', default='RonMega Gaming Clip 🎮')
    parser.add_argument('--desc', default='#ronmegagaming #gaming #gamer #Shorts')
    args = parser.parse_args()

    vid_id, url = upload_video(args.file, args.title, args.desc)
    print(f'Video ID: {vid_id}')
    print(f'URL: {url}')
