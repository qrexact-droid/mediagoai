#!/usr/bin/env python3
"""
WUPP Tweet Image Generator
Creates branded images for Twitter posts — quote cards, stat cards, hype cards.
Usage: python3 wupp_image_gen.py [output_path] [type] [text]
Types: quote, stat, hype, burn, community
"""

import sys, os, random, textwrap
from PIL import Image, ImageDraw, ImageFont

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
LOGO_PATH = f'{WORKSPACE}/wupp_logo_256.png'
OUTPUT_DIR = f'{WORKSPACE}/config/wupp_images'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Color palettes per card type
THEMES = {
    "quote": {
        "bg": [(15, 10, 30), (25, 15, 50)],       # deep purple gradient
        "accent": (140, 80, 255),
        "text": (230, 220, 255),
        "sub": (140, 120, 200),
        "bar": (100, 50, 200),
    },
    "stat": {
        "bg": [(5, 20, 15), (10, 35, 25)],          # deep green
        "accent": (0, 230, 130),
        "text": (200, 255, 230),
        "sub": (100, 200, 150),
        "bar": (0, 180, 100),
    },
    "hype": {
        "bg": [(30, 10, 5), (55, 20, 5)],            # dark orange/fire
        "accent": (255, 140, 0),
        "text": (255, 235, 200),
        "sub": (200, 130, 60),
        "bar": (220, 100, 0),
    },
    "burn": {
        "bg": [(20, 5, 5), (40, 10, 5)],             # deep red
        "accent": (255, 60, 60),
        "text": (255, 220, 220),
        "sub": (200, 100, 100),
        "bar": (180, 30, 30),
    },
    "community": {
        "bg": [(5, 15, 30), (10, 25, 50)],           # navy blue
        "accent": (50, 160, 255),
        "text": (210, 230, 255),
        "sub": (100, 150, 220),
        "bar": (30, 120, 220),
    },
}

def get_font(size, bold=False):
    """Try to load a system font, fall back to default."""
    candidates = [
        '/System/Library/Fonts/Helvetica.ttc',
        '/System/Library/Fonts/HelveticaNeue.ttc',
        '/System/Library/Fonts/SFNSDisplay.ttf',
        '/System/Library/Fonts/SFCompactDisplay.ttf',
        '/Library/Fonts/Arial Bold.ttf' if bold else '/Library/Fonts/Arial.ttf',
        '/System/Library/Fonts/Supplemental/Arial.ttf',
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except:
                continue
    return ImageFont.load_default()

def draw_gradient_bg(draw, w, h, colors):
    """Draw a vertical gradient background."""
    c1, c2 = colors
    for y in range(h):
        t = y / h
        r = int(c1[0] + (c2[0] - c1[0]) * t)
        g = int(c1[1] + (c2[1] - c1[1]) * t)
        b = int(c1[2] + (c2[2] - c1[2]) * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b))

def add_noise_texture(img, strength=8):
    """Add subtle grain texture for depth."""
    import random as rnd
    pixels = img.load()
    w, h = img.size
    for _ in range(w * h // 10):
        x = rnd.randint(0, w - 1)
        y = rnd.randint(0, h - 1)
        p = pixels[x, y]
        delta = rnd.randint(-strength, strength)
        pixels[x, y] = tuple(max(0, min(255, c + delta)) for c in p)
    return img

def wrap_text(text, font, max_width, draw):
    """Word-wrap text to fit within max_width pixels."""
    words = text.split()
    lines = []
    current = []
    for word in words:
        test = ' '.join(current + [word])
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current.append(word)
        else:
            if current:
                lines.append(' '.join(current))
            current = [word]
    if current:
        lines.append(' '.join(current))
    return lines

def make_card(card_type, headline, subtext=None, output_path=None):
    """
    Generate a branded WUPP image card.
    card_type: quote | stat | hype | burn | community
    headline: main bold text
    subtext: smaller supporting text (optional)
    output_path: where to save. Defaults to OUTPUT_DIR/wupp_{type}_{random}.png
    """
    theme = THEMES.get(card_type, THEMES["quote"])
    W, H = 1200, 675  # 16:9, ideal for Twitter

    img = Image.new("RGB", (W, H))
    draw = ImageDraw.Draw(img)

    # Background gradient
    draw_gradient_bg(draw, W, H, theme["bg"])

    # Accent bar on left edge
    draw.rectangle([(0, 0), (8, H)], fill=theme["accent"])

    # Top decorative line
    draw.rectangle([(0, 0), (W, 4)], fill=theme["bar"])

    # Bottom decorative line
    draw.rectangle([(0, H - 4), (W, H)], fill=theme["bar"])

    # Load and paste logo (top-right)
    try:
        logo = Image.open(LOGO_PATH).convert("RGBA")
        logo_size = 100
        logo = logo.resize((logo_size, logo_size), Image.LANCZOS)
        # Add slight glow effect around logo
        glow = Image.new("RGBA", (logo_size + 20, logo_size + 20), (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow)
        ac = theme["accent"]
        for i in range(10, 0, -1):
            alpha = int(20 * (11 - i))
            glow_draw.ellipse(
                [(i, i), (logo_size + 20 - i, logo_size + 20 - i)],
                outline=(ac[0], ac[1], ac[2], alpha)
            )
        img_rgba = img.convert("RGBA")
        img_rgba.paste(glow, (W - logo_size - 30, 20), glow)
        img_rgba.paste(logo, (W - logo_size - 20, 30), logo)
        img = img_rgba.convert("RGB")
        draw = ImageDraw.Draw(img)
    except Exception as e:
        print(f"Logo paste skipped: {e}")

    # WUPP brand label (top left)
    brand_font = get_font(22, bold=True)
    draw.text((30, 28), "W U P P C O I N . I O", font=brand_font, fill=theme["accent"])

    # Tagline micro text
    tag_font = get_font(16)
    draw.text((30, 56), "Wake Up & Push Purposefully  •  $WUPP on Solana", font=tag_font, fill=theme["sub"])

    # Divider line under header
    draw.rectangle([(25, 80), (W - 25, 82)], fill=theme["bar"])

    # Main headline
    headline_font = get_font(54, bold=True)
    text_x = 50
    text_max_w = W - 180
    lines = wrap_text(headline, headline_font, text_max_w, draw)

    # Vertically center the text block
    line_height = 66
    total_text_h = len(lines) * line_height
    if subtext:
        sub_font = get_font(30)
        sub_lines = wrap_text(subtext, sub_font, text_max_w, draw)
        total_text_h += len(sub_lines) * 40 + 30
    text_y = max(110, (H - total_text_h) // 2 + 20)

    for line in lines:
        draw.text((text_x, text_y), line, font=headline_font, fill=theme["text"])
        text_y += line_height

    # Subtext
    if subtext:
        text_y += 20
        sub_font = get_font(30)
        for line in sub_lines:
            draw.text((text_x, text_y), line, font=sub_font, fill=theme["sub"])
            text_y += 40

    # Bottom accent: $WUPP pill badge
    badge_font = get_font(20, bold=True)
    badge_text = "$WUPP"
    badge_bbox = draw.textbbox((0, 0), badge_text, font=badge_font)
    badge_w = badge_bbox[2] - badge_bbox[0] + 30
    badge_h = 32
    badge_x = 30
    badge_y = H - 55
    draw.rounded_rectangle(
        [(badge_x, badge_y), (badge_x + badge_w, badge_y + badge_h)],
        radius=8, fill=theme["accent"]
    )
    draw.text((badge_x + 15, badge_y + 6), badge_text, font=badge_font, fill=(10, 5, 20))

    # Solana badge
    sol_text = "on Solana"
    sol_bbox = draw.textbbox((0, 0), sol_text, font=badge_font)
    sol_w = sol_bbox[2] - sol_bbox[0] + 30
    sol_x = badge_x + badge_w + 12
    draw.rounded_rectangle(
        [(sol_x, badge_y), (sol_x + sol_w, badge_y + badge_h)],
        radius=8, fill=theme["bar"]
    )
    draw.text((sol_x + 15, badge_y + 6), sol_text, font=badge_font, fill=theme["text"])

    # Add subtle noise
    img = add_noise_texture(img, strength=5)

    # Save
    if not output_path:
        output_path = f"{OUTPUT_DIR}/wupp_{card_type}_{random.randint(1000,9999)}.png"
    img.save(output_path, "PNG", optimize=True)
    print(f"Saved: {output_path}")
    return output_path


# Pre-defined card sets matching the content calendar types
CARD_CONTENT = {
    "culture": ("quote", "Wake Up & Push Purposefully.", "Different breed. Built different."),
    "education": ("stat", "1% BURN on every transaction.", "Automatic. Built into the contract. Not a promise."),
    "trust": ("burn", "Liquidity locked.\nDev tokens vested.", "You can't rug what you can't touch."),
    "roadmap": ("community", "Phase 1: Build the army.\nPhase 2: Launch.", "We build before we launch. Every time."),
    "tokenomics": ("stat", "1,000,000,000 tokens.\nFixed. Forever.", "Mint revoked. Supply only goes down."),
    "hype": ("hype", "You are watching WUPP\nbefore the blowup.", "This is the moment. Be early."),
    "engagement": ("community", "The WUPP Army\ndoesn't sleep.", "Wake Up & Push Purposefully."),
}

def make_card_for_content_type(content_type, output_path=None):
    """Make a card matching a content type from the calendar."""
    if content_type not in CARD_CONTENT:
        content_type = "culture"
    card_type, headline, subtext = CARD_CONTENT[content_type]
    return make_card(card_type, headline, subtext, output_path)


if __name__ == "__main__":
    if len(sys.argv) >= 4:
        out = sys.argv[1]
        ctype = sys.argv[2]
        headline = sys.argv[3]
        sub = sys.argv[4] if len(sys.argv) > 4 else None
        make_card(ctype, headline, sub, out)
    elif len(sys.argv) == 2:
        # Generate one card per content type as preview
        content_type = sys.argv[1]
        path = make_card_for_content_type(content_type)
        print(path)
    else:
        # Generate all card types as samples
        print("Generating sample cards for all content types...")
        for ct in CARD_CONTENT:
            path = make_card_for_content_type(ct)
        print("Done.")
