#!/usr/bin/env python3
# WUPP Daily Twitter Poster
import tweepy, json, sys, random
from datetime import datetime

with open('/Users/ronniemack/.openclaw/workspace/config/twitter_credentials.json') as f:
    creds = json.load(f)

client = tweepy.Client(
    consumer_key=creds['api_key'],
    consumer_secret=creds['api_secret'],
    access_token=creds['access_token'],
    access_token_secret=creds['access_token_secret']
)

# Daily posts by day of week (0=Mon, 6=Sun)
posts = {
    0: """Monday grind hits different when you've got a purpose. 💪

W = Wake Up
U = &
P = Push
P = Purposefully

$WUPP is built for the ones who never quit.
wuppcoin.io
#Solana #WUPP #memecoin #crypto""",

    1: """📊 $WUPP Tokenomics — built to last.

1,000,000,000 total supply
✅ 1% burned every transaction
✅ 25% liquidity — LOCKED forever
✅ Dev tokens VESTED 90 days
✅ Mint authority REVOKED

No rugs. No dumps. Math doesn't lie.
wuppcoin.io
#Solana #WUPP""",

    2: """📍 WUPP Roadmap Update

Phase 1 — ACTIVE ✅
Building community before the launch.
Real people. Real movement.

Phase 2 — Coming soon 🔥
Solana deployment. Liquidity locked. Trading opens.

The foundation is being laid RIGHT NOW.
wuppcoin.io
#Solana #WUPP #memecoin""",

    3: """Real talk — why are you here?

For most of us it's simple.
We're tired of watching others win.
We want our shot.

$WUPP was built for THAT person.
The grinder. The hustler. The one who refuses to quit.

Are you WUPP? 👇
wuppcoin.io
#Solana #WUPP #crypto""",

    4: """Friday energy. 🔥

While everyone else is winding down —
we're building up.

$WUPP launches on Solana soon.
Community is growing.
Liquidity will be locked.
Contract will be verified.

The ones who got in early always win.
wuppcoin.io
#Solana #WUPP #memecoin #crypto""",

    5: """The WUPP Army is growing. 🪖

Every day more people are discovering what $WUPP stands for.

Not just a coin.
A mindset.
A movement.
A community of people who Wake Up & Push Purposefully.

Join us → wuppcoin.io
#Solana #WUPP""",

    6: """Sunday reminder 🙏

$WUPP isn't just a ticker symbol.

It's a promise to yourself.
Wake up tomorrow with purpose.
Push harder than yesterday.
Build something real.

That's what this coin represents.
wuppcoin.io
#Solana #WUPP #memecoin"""
}

day = datetime.now().weekday()
tweet = posts[day]

# Allow override from command line
if len(sys.argv) > 1:
    tweet = ' '.join(sys.argv[1:])

try:
    response = client.create_tweet(text=tweet)
    print(f"✅ Tweet posted! ID: {response.data['id']}")
    print(f"Content: {tweet[:80]}...")
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)
