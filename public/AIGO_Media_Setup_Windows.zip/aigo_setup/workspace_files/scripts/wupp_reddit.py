#!/usr/bin/env python3
"""
WUPP Reddit Poster
Posts WUPP coin content to target subreddits using saved browser session.
Usage: python3 wupp_reddit.py [--subreddit r/SolanaMemeCoins] [--dry-run]
"""

import asyncio
import argparse
import json
import os
import random
import sys
from datetime import datetime
from pathlib import Path
from playwright.async_api import async_playwright

WORKSPACE = Path(__file__).parent.parent
SESSION_DIR = WORKSPACE / "config" / "reddit_session"
LOGO_PATH = WORKSPACE / "wupp_logo.png"  # drop logo here

SUBREDDITS = [
    "r/SolanaMemeCoins",
    "r/CryptoMoonShots",
    "r/SatoshiStreetBets",
    "r/memecoin",
    "r/CryptoMarkets",
]

POSTS = [
    {
        "title": "WUPP is building community first — launch comes later 🐾",
        "body": (
            "Not dropping a contract address today. WUPP ($WUPP) is doing this the right way — "
            "3 months of community building BEFORE mainnet deploy.\n\n"
            "Why? Because rugs happen when devs rush. We're not rushing.\n\n"
            "📌 Tokenomics: 1% burn per tx | locked liquidity | 90-day dev cliff + 12mo vest\n"
            "🐦 Twitter: @WUPPcoin\n"
            "📣 Telegram: @WUPParmy\n\n"
            "Contract drops when the army is ready. Get in early."
        ),
    },
    {
        "title": "Why WUPP is waiting 3 months to launch on Solana 🔒",
        "body": (
            "Most meme coins rug because they launch before the community exists. "
            "We're flipping that script.\n\n"
            "WUPP ($WUPP) on Solana:\n"
            "- 1 billion supply\n"
            "- 1% burn per transaction\n"
            "- Liquidity locked at launch\n"
            "- Dev tokens: 90-day cliff, 12-month vest\n"
            "- No presale, no insider allocation\n\n"
            "We're 3 months out. Follow @WUPPcoin on Twitter and join @WUPParmy on Telegram. "
            "Be there when the contract drops."
        ),
    },
    {
        "title": "WUPP Army is growing — Solana meme coin building the right way 🪖",
        "body": (
            "The WUPP Army is expanding. We're not launching until the community is solid.\n\n"
            "$WUPP on Solana — 1B supply, 1% burn per tx, locked liq, vested dev tokens.\n\n"
            "No contract address yet — that's intentional. When we deploy, you'll want to already be in.\n\n"
            "🐦 @WUPPcoin | 📣 @WUPParmy\n\n"
            "WUPP."
        ),
    },
]


async def post_to_reddit(subreddit: str, post: dict, logo_path, dry_run: bool):
    async with async_playwright() as p:
        browser = await p.chromium.launch_persistent_context(
            user_data_dir=str(SESSION_DIR),
            headless=False,
            args=["--no-sandbox"],
        )
        page = browser.pages[0] if browser.pages else await browser.new_page()

        submit_url = f"https://www.reddit.com/{subreddit}/submit"
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Navigating to {submit_url}")
        await page.goto(submit_url, wait_until="domcontentloaded")
        await page.wait_for_timeout(3000)

        # Check if logged in
        if "login" in page.url or "register" in page.url:
            print("❌ Not logged in — Reddit session may have expired.")
            await browser.close()
            return False

        if dry_run:
            print(f"[DRY RUN] Would post to {subreddit}:")
            print(f"  Title: {post['title']}")
            print(f"  Body: {post['body'][:100]}...")
            await browser.close()
            return True

        # Make sure we're on the Text tab
        try:
            text_tab = page.locator('button:has-text("Text")').first
            await text_tab.click()
            await page.wait_for_timeout(1000)
        except Exception:
            pass

        # Fill title — new Reddit uses innerTextArea, first one is the title
        title_input = page.locator('#innerTextArea').first
        await title_input.click()
        await title_input.fill(post["title"])
        await page.wait_for_timeout(500)

        # Fill body — the rich text editor div
        body_input = page.locator('.outline-none.relative').first
        await body_input.click()
        await body_input.type(post["body"])
        await page.wait_for_timeout(500)

        # Submit — the Post button (last one, enabled after title filled)
        submit_btn = page.locator('button:has-text("Post")').last
        print(f"Submitting to {subreddit}...")
        await submit_btn.click()
        await page.wait_for_timeout(5000)

        # Check for success
        current_url = page.url
        if "comments" in current_url or subreddit.lower().replace("r/", "") in current_url:
            print(f"✅ Posted to {subreddit}: {current_url}")
            await browser.close()
            return True
        else:
            # Screenshot for debugging
            screenshot_path = WORKSPACE / f"reddit_{subreddit.replace('r/', '')}_{datetime.now().strftime('%H%M%S')}.png"
            await page.screenshot(path=str(screenshot_path))
            print(f"⚠️  Uncertain — screenshot saved: {screenshot_path}")
            await browser.close()
            return False

    return False


async def main():
    parser = argparse.ArgumentParser(description="WUPP Reddit poster")
    parser.add_argument("--subreddit", default="r/SolanaMemeCoins", help="Target subreddit")
    parser.add_argument("--all", action="store_true", help="Post to all target subreddits")
    parser.add_argument("--dry-run", action="store_true", help="Preview without posting")
    args = parser.parse_args()

    logo = LOGO_PATH if LOGO_PATH.exists() else None
    if not logo:
        print("ℹ️  No wupp_logo.png found — posting text only")

    post = random.choice(POSTS)

    if args.all:
        for sub in SUBREDDITS:
            print(f"\n--- {sub} ---")
            success = await post_to_reddit(sub, post, logo, args.dry_run)
            if success and not args.dry_run:
                # Wait between posts to avoid spam detection
                wait = random.randint(120, 300)
                print(f"Waiting {wait}s before next post...")
                await asyncio.sleep(wait)
    else:
        await post_to_reddit(args.subreddit, post, logo, args.dry_run)


if __name__ == "__main__":
    asyncio.run(main())
