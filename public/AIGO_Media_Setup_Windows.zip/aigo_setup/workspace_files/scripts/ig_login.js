/**
 * Instagram Login — saves cookies for future automation
 * Run: node scripts/ig_login.js
 * Follow the prompts to log in, then cookies are saved automatically.
 */
const { chromium } = require('/Users/ronniemack/.npm/_npx/e41f203b7505f1fb/node_modules/playwright');
const fs = require('fs');
const readline = require('readline');

const COOKIES_FILE = '/Users/ronniemack/.openclaw/workspace/config/ig_cookies.json';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, res));

(async () => {
  console.log('\n📸 Instagram Login — Saving Session\n');

  const browser = await chromium.launch({ headless: false, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 }
  });
  const page = await ctx.newPage();

  await page.goto('https://www.instagram.com/accounts/login/', { waitUntil: 'domcontentloaded' });
  console.log('Browser opened. Please log into Instagram in the window that appeared.');
  console.log('Use your RonMega Gaming account credentials.\n');

  await ask('Press Enter here AFTER you have fully logged in and see your Instagram feed...');

  const cookies = await ctx.cookies();
  fs.writeFileSync(COOKIES_FILE, JSON.stringify(cookies, null, 2));
  console.log(`\n✅ Instagram cookies saved to: ${COOKIES_FILE}`);
  console.log('Instagram automation is now ready.\n');

  await browser.close();
  rl.close();
})().catch(e => { console.error('Error:', e.message); process.exit(1); });
