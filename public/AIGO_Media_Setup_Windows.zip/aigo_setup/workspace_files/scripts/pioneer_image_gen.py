#!/usr/bin/env python3
"""
Pioneer Cache Social Image Generator
Creates branded cards for Twitter, forums, and directories.
Usage: python3 pioneer_image_gen.py [type]
Types: fear, value, feature, gift, cta
"""

import sys, os, random
from PIL import Image, ImageDraw, ImageFont

WORKSPACE = '/Users/ronniemack/.openclaw/workspace'
OUTPUT_DIR = f'{WORKSPACE}/config/pioneer_images'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Earthy, rugged survival palette
THEMES = {
    "fear": {
        "bg": [(8, 8, 8), (20, 15, 10)],
        "accent": (200, 50, 30),
        "text": (240, 235, 220),
        "sub": (170, 150, 130),
        "bar": (150, 30, 20),
        "badge_bg": (200, 50, 30),
        "badge_text": (255, 245, 235),
    },
    "value": {
        "bg": [(10, 18, 10), (15, 30, 15)],
        "accent": (80, 180, 60),
        "text": (230, 245, 220),
        "sub": (130, 170, 110),
        "bar": (50, 130, 40),
        "badge_bg": (50, 150, 40),
        "badge_text": (240, 255, 235),
    },
    "feature": {
        "bg": [(12, 15, 20), (18, 25, 35)],
        "accent": (100, 160, 220),
        "text": (220, 230, 245),
        "sub": (120, 150, 190),
        "bar": (60, 110, 180),
        "badge_bg": (60, 120, 200),
        "badge_text": (230, 240, 255),
    },
    "gift": {
        "bg": [(20, 12, 5), (35, 20, 8)],
        "accent": (210, 150, 40),
        "text": (250, 240, 210),
        "sub": (180, 150, 90),
        "bar": (160, 110, 30),
        "badge_bg": (200, 140, 30),
        "badge_text": (255, 250, 230),
    },
    "cta": {
        "bg": [(5, 10, 18), (10, 20, 35)],
        "accent": (50, 200, 150),
        "text": (220, 245, 235),
        "sub": (100, 180, 150),
        "bar": (30, 150, 110),
        "badge_bg": (30, 160, 120),
        "badge_text": (230, 255, 245),
    },
}

CARD_CONTENT = {
    "fear": {
        "headline": "When the grid goes down,\nGoogle goes with it.",
        "sub": "The Pioneer Cache works when nothing else does.",
        "badge": "$5.99 ONE-TIME",
        "url": "thepioneercache.com",
    },
    "value": {
        "headline": "34 survival topics.\nOne file.\nNo internet. Ever.",
        "sub": "Water · Fire · First Aid · Foraging · Off-Grid Power · Navigation",
        "badge": "$5.99 • YOURS FOREVER",
        "url": "thepioneercache.com",
    },
    "feature": {
        "headline": "Works offline.\nWorks forever.\nWorks anywhere.",
        "sub": "Open in Chrome, Safari, Firefox — no app, no account, no connection needed.",
        "badge": "INSTANT DOWNLOAD",
        "url": "thepioneercache.com",
    },
    "gift": {
        "headline": "Give them knowledge\nthat works when\nnothing else does.",
        "sub": "The Pioneer Cache — $5.99. One time. They own it forever.",
        "badge": "PERFECT GIFT",
        "url": "thepioneercache.com",
    },
    "cta": {
        "headline": "Your offline\nsurvival library.",
        "sub": "34 topics. One HTML file. Buy once. Open forever.",
        "badge": "GET IT NOW — $5.99",
        "url": "thepioneercache.com",
    },
}

def get_font(size, bold=False):
    candidates = [
        '/System/Library/Fonts/Helvetica.ttc',
        '/System/Library/Fonts/HelveticaNeue.ttc',
        '/Library/Fonts/Arial Bold.ttf' if bold else '/Library/Fonts/Arial.ttf',
        '/System/Library/Fonts/Supplemental/Arial.ttf',
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except:
                continue
    return ImageFont.load_default()

def draw_gradient_bg(draw, w, h, colors):
    c1, c2 = colors
    for y in range(h):
        t = y / h
        r = int(c1[0] + (c2[0] - c1[0]) * t)
        g = int(c1[1] + (c2[1] - c1[1]) * t)
        b = int(c1[2] + (c2[2] - c1[2]) * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b))

def add_campfire_texture(img, theme):
    """Add subtle warm grain and vignette."""
    from PIL import ImageFilter
    pixels = img.load()
    w, h = img.size
    import random as rnd
    for _ in range(w * h // 12):
        x = rnd.randint(0, w - 1)
        y = rnd.randint(0, h - 1)
        p = pixels[x, y]
        delta = rnd.randint(-6, 6)
        pixels[x, y] = tuple(max(0, min(255, c + delta)) for c in p)
    return img

def wrap_text(text, font, max_width, draw):
    lines_in = text.split('\n')
    out = []
    for raw_line in lines_in:
        words = raw_line.split()
        if not words:
            out.append('')
            continue
        current = []
        for word in words:
            test = ' '.join(current + [word])
            bbox = draw.textbbox((0, 0), test, font=font)
            if bbox[2] - bbox[0] <= max_width:
                current.append(word)
            else:
                if current:
                    out.append(' '.join(current))
                current = [word]
        if current:
            out.append(' '.join(current))
    return out

def make_pioneer_card(card_type, output_path=None):
    theme = THEMES.get(card_type, THEMES["value"])
    content = CARD_CONTENT.get(card_type, CARD_CONTENT["value"])
    W, H = 1200, 675

    img = Image.new("RGB", (W, H))
    draw = ImageDraw.Draw(img)
    draw_gradient_bg(draw, W, H, theme["bg"])

    # Left edge accent bar
    draw.rectangle([(0, 0), (6, H)], fill=theme["accent"])
    # Top/bottom lines
    draw.rectangle([(0, 0), (W, 3)], fill=theme["bar"])
    draw.rectangle([(0, H - 3), (W, H)], fill=theme["bar"])

    # Brand header
    brand_font = get_font(26, bold=True)
    draw.text((30, 25), "THE PIONEER CACHE", font=brand_font, fill=theme["accent"])
    tag_font = get_font(17)
    draw.text((30, 58), "thepioneercache.com  •  Offline Survival Knowledge", font=tag_font, fill=theme["sub"])
    draw.rectangle([(25, 85), (W - 25, 87)], fill=theme["bar"])

    # Compass rose / decorative element (top right)
    cx, cy, cr = W - 70, 55, 40
    draw.ellipse([(cx - cr, cy - cr), (cx + cr, cy + cr)], outline=theme["accent"], width=2)
    draw.ellipse([(cx - cr // 2, cy - cr // 2), (cx + cr // 2, cy + cr // 2)], outline=theme["bar"], width=1)
    # N/S/E/W marks
    comp_font = get_font(13, bold=True)
    draw.text((cx - 5, cy - cr - 16), "N", font=comp_font, fill=theme["accent"])
    draw.text((cx - 5, cy + cr + 2), "S", font=comp_font, fill=theme["sub"])
    draw.text((cx + cr + 4, cy - 7), "E", font=comp_font, fill=theme["sub"])
    draw.text((cx - cr - 14, cy - 7), "W", font=comp_font, fill=theme["sub"])
    draw.line([(cx, cy - cr), (cx, cy + cr)], fill=theme["bar"], width=1)
    draw.line([(cx - cr, cy), (cx + cr, cy)], fill=theme["bar"], width=1)

    # Main headline
    head_font = get_font(58, bold=True)
    text_x = 50
    text_max_w = W - 100
    head_lines = wrap_text(content["headline"], head_font, text_max_w, draw)

    sub_font = get_font(28)
    sub_lines = wrap_text(content["sub"], sub_font, text_max_w, draw)

    line_h = 70
    sub_h = 38
    total_h = len(head_lines) * line_h + (len(sub_lines) * sub_h + 25 if content["sub"] else 0)
    text_y = max(105, (H - total_h) // 2 + 15)

    for line in head_lines:
        draw.text((text_x, text_y), line, font=head_font, fill=theme["text"])
        text_y += line_h

    if content["sub"]:
        text_y += 15
        for line in sub_lines:
            draw.text((text_x, text_y), line, font=sub_font, fill=theme["sub"])
            text_y += sub_h

    # Badge pill (bottom left)
    badge_font = get_font(21, bold=True)
    badge_text = content["badge"]
    b_bbox = draw.textbbox((0, 0), badge_text, font=badge_font)
    b_w = b_bbox[2] - b_bbox[0] + 36
    b_h = 36
    b_x, b_y = 30, H - 62
    draw.rounded_rectangle([(b_x, b_y), (b_x + b_w, b_y + b_h)], radius=8, fill=theme["badge_bg"])
    draw.text((b_x + 18, b_y + 8), badge_text, font=badge_font, fill=theme["badge_text"])

    # URL (bottom right)
    url_font = get_font(20)
    u_bbox = draw.textbbox((0, 0), content["url"], font=url_font)
    u_w = u_bbox[2] - u_bbox[0]
    draw.text((W - u_w - 35, H - 52), content["url"], font=url_font, fill=theme["accent"])

    img = add_campfire_texture(img, theme)

    if not output_path:
        output_path = f"{OUTPUT_DIR}/pioneer_{card_type}_{random.randint(1000,9999)}.png"
    img.save(output_path, "PNG", optimize=True)
    print(f"Saved: {output_path}")
    return output_path


if __name__ == "__main__":
    if len(sys.argv) > 1:
        card_type = sys.argv[1]
        path = make_pioneer_card(card_type)
    else:
        print("Generating all Pioneer Cache card types...")
        for ct in CARD_CONTENT:
            make_pioneer_card(ct)
        print("Done.")
