#!/usr/bin/env python3
# WUPP Content Calendar - 7 days x 3 posts, 2 weeks rotating
# Times: 7AM (morning), 12PM (midday), 9PM (prime)
# Rule: NEVER repeat within a week. Slogan "Wake Up & Push Purposefully" is the only constant.
# Week rotation: odd ISO weeks = week 1, even ISO weeks = week 2

from datetime import datetime
from wupp_content_week2 import CONTENT_WEEK2

def get_active_content():
    """Returns the content dict for the current ISO week (alternates week1/week2)."""
    week_num = datetime.now().isocalendar()[1]
    if week_num % 2 == 1:
        return _CONTENT_WEEK1
    else:
        return CONTENT_WEEK2

# Alias so existing code using CONTENT still works (defaults to current week)
class _ContentProxy(dict):
    def __getitem__(self, key):
        return get_active_content()[key]
    def get(self, key, default=None):
        return get_active_content().get(key, default)

# Week 1 content stored under private name
_CONTENT_WEEK1 = None  # filled below after the dict definition


_CONTENT_WEEK1 = {
    # MONDAY
    "MON_7AM": {
        "text": "Most people hit snooze and call it a rest day.\n\nThe WUPP Army was already moving before the alarm went off.\n\nDifferent breed.\nwuppcoin.io\n#Solana #WUPP #CryptoTwitter #hustle #Web3",
        "type": "culture"
    },
    "MON_12PM": {
        "text": "Let's talk numbers.\n\n1,000,000,000 tokens minted. Once.\nMint authority: REVOKED permanently.\nNew tokens: impossible.\nSupply: shrinking with every transaction.\n\nDeflation is built in. Not promised.\nwuppcoin.io\n#Solana #WUPP #memecoin #altcoin #SolanaMemecoins",
        "type": "education"
    },
    "MON_9PM": {
        "text": "You know what separates winners from dreamers?\n\nDreamers wait for the right time.\nWinners move and make the time right.\n\nWake Up & Push Purposefully.\n\nwuppcoin.io\n#WUPP #Solana #CryptoTwitter #Web3 #buildingpublicly",
        "type": "engagement"
    },

    # TUESDAY
    "TUE_7AM": {
        "text": "Every Solana transaction that includes WUPP burns 1% automatically.\n\nNo vote. No governance. No debate.\nJust math doing its job.\n\nSmaller supply. Same demand. You do the math.\nwuppcoin.io\n#Solana #WUPP #memecoin #SolanaMemecoins #altcoin",
        "type": "education"
    },
    "TUE_12PM": {
        "text": "Rugs happen because dev wallets dump.\n\nOurs can't.\n\n90-day cliff. 12-month linear vest.\nDev tokens are locked by code, not by promise.\n\nThis is what trust looks like in crypto.\nwuppcoin.io\n#Solana #WUPP #CryptoTwitter #Web3 #DeFi",
        "type": "trust"
    },
    "TUE_9PM": {
        "text": "Quick poll for the timeline:\n\nWhat matters most to you in a new coin?\n\nA) Team transparency\nB) Locked liquidity\nC) Burn mechanism\nD) Community energy\n\nDrop your answer below. Building this for YOU.\n#WUPP #Solana #memecoin #CryptoTwitter",
        "type": "engagement"
    },

    # WEDNESDAY
    "WED_7AM": {
        "text": "Phase 1 is happening right now.\n\nNo contract yet. No price. No hype.\n\nJust builders building and soldiers showing up daily.\n\nThis is what a real launch looks like from the ground floor.\nwuppcoin.io\n#Solana #WUPP #memecoin #Web3 #buildingpublicly",
        "type": "roadmap"
    },
    "WED_12PM": {
        "text": "Anti-snipe protection.\nMax wallet limits at launch.\n5-minute trading delay after deploy.\nEmergency pause switch.\n\nWe coded every defense because we've seen every attack.\n\nThis contract was built by people who got burned before.\nwuppcoin.io\n#Solana #WUPP #DeFi #CryptoTwitter #altcoin",
        "type": "education"
    },
    "WED_9PM": {
        "text": "The name alone hits different.\n\nW - Wake Up\nU - and\nP - Push\nP - Purposefully\n\nFour words. One mission.\nSay it every morning and see what changes.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #grind #memecoin",
        "type": "culture"
    },

    # THURSDAY
    "THU_7AM": {
        "text": "15% of all WUPP supply is allocated to marketing.\n\nThat is 150,000,000 tokens for influencers, campaigns, and community growth.\n\nNot sitting in a dev wallet. Working.\nwuppcoin.io\n#Solana #WUPP #SolanaMemecoins #altcoin #CryptoTwitter",
        "type": "tokenomics"
    },
    "THU_12PM": {
        "text": "The people getting rich in crypto right now?\n\nThey were not lucky.\nThey were early.\nThey did the research.\nThey held conviction.\n\nThat window exists right now with WUPP.\nwuppcoin.io\n#Solana #WUPP #memecoin #Web3 #CryptoTwitter",
        "type": "hype"
    },
    "THU_9PM": {
        "text": "Tag someone who needs to Wake Up & Push Purposefully tomorrow morning.\n\nSend them something real.\n\nwuppcoin.io\n#WUPP #Solana #hustle #motivation #CryptoTwitter",
        "type": "engagement"
    },

    # FRIDAY
    "FRI_7AM": {
        "text": "Liquidity locked means nobody can drain the pool.\nNot the dev. Not the team. Not anyone.\n\nWhen we lock it, it stays locked.\nThat is not a promise. That is a transaction.\n\nwuppcoin.io\n#Solana #WUPP #DeFi #memecoin #SolanaMemecoins",
        "type": "trust"
    },
    "FRI_12PM": {
        "text": "After WUPP launches on Raydium:\n\nStep 1 - Jupiter auto-lists it\nStep 2 - Dexscreener picks it up\nStep 3 - CoinGecko submission\nStep 4 - CoinMarketCap submission\n\nEvery step is already planned. Nothing left to chance.\nwuppcoin.io\n#Solana #WUPP #memecoin #altcoin #CryptoTwitter",
        "type": "roadmap"
    },
    "FRI_9PM": {
        "text": "Friday night and the WUPP Army does not sleep.\n\nWhile the market chills, we build.\nWhile others party, we position.\n\nSee you on the other side.\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #grind #CryptoTwitter #memecoin",
        "type": "culture"
    },

    # SATURDAY
    "SAT_7AM": {
        "text": "10% of supply reserved for community rewards.\n\nStaking. Contests. Holder drops. Community events.\n\n100,000,000 tokens going back to the people who built this.\nNot a promise. It is already allocated.\nwuppcoin.io\n#Solana #WUPP #DeFi #altcoin #SolanaMemecoins",
        "type": "tokenomics"
    },
    "SAT_12PM": {
        "text": "You ever watch a coin blow up and think you missed it?\n\nYou are watching WUPP before the blowup.\n\nThis is the moment people look back at and say\n'I was there from the beginning.'\n\nwuppcoin.io\n#Solana #WUPP #memecoin #CryptoTwitter #Web3",
        "type": "hype"
    },
    "SAT_9PM": {
        "text": "Real question for the Solana community:\n\nWhat made you believe in your best investment?\n\nWas it the tech? The team? The community? The timing?\n\nTelling us because we want to build exactly that.\n#WUPP #Solana #CryptoTwitter #DeFi",
        "type": "engagement"
    },

    # SUNDAY
    "SUN_7AM": {
        "text": "Sunday is not a day off.\n\nIt is a head start.\n\nWhile the week resets, position yourself.\nWhile others sleep in, level up.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #hustle #grind #CryptoTwitter",
        "type": "culture"
    },
    "SUN_12PM": {
        "text": "Backup domain: wuppcoin.com\nPrimary domain: wuppcoin.io\nWebsite: LIVE\nWhitepaper: PUBLISHED\nTwitter: ACTIVE\nTelegram: ACTIVE\nSmart contract: READY\n\nEverything is in place. The only thing left is the launch.\nwuppcoin.io\n#Solana #WUPP #memecoin #SolanaMemecoins #altcoin",
        "type": "trust"
    },
    "SUN_9PM": {
        "text": "A new week starts in a few hours.\n\nMost will wish. Some will plan. Few will execute.\n\nWUPP was built by the ones who execute.\nFor the ones who execute.\n\nWake Up & Push Purposefully.\nwuppcoin.io\n#WUPP #Solana #Web3 #hustle #memecoin",
        "type": "culture"
    },
}

# Proxy object that auto-selects week based on ISO week number
CONTENT = _ContentProxy()

if __name__ == "__main__":
    # Print full calendar
    days = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
    times = ["7AM", "12PM", "9PM"]
    for day in days:
        print(f"\n=== {day} ===")
        for t in times:
            key = f"{day}_{t}"
            post = CONTENT[key]
            print(f"\n[{t}] ({post['type'].upper()})")
            print(post['text'])
            print()
