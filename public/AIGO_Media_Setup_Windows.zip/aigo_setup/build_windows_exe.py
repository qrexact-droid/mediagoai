#!/usr/bin/env python3
"""
Builds AIGO_Media_Setup.exe from the .bat file using PyInstaller.
Run this ON the Windows machine to create the .exe.

Requirements: pip install pyinstaller
Then run: python build_windows_exe.py
"""

import os, subprocess, sys

print("Building AIGO Media Setup EXE...")
print("This must be run on a Windows machine.")
print()

# Create the Python launcher that calls the bat
launcher = '''
import os, sys, subprocess, time, webbrowser
from pathlib import Path

def main():
    script_dir = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
    bat_file = script_dir / "AIGO_Media_Setup_Windows.bat"
    
    # Start the bat silently
    subprocess.Popen(
        ["cmd", "/c", str(bat_file)],
        creationflags=subprocess.CREATE_NO_WINDOW
    )
    
    # Open the branded installer UI immediately
    time.sleep(2)
    webbrowser.open("http://127.0.0.1:8899/installer_ui.html")

if __name__ == "__main__":
    main()
'''

with open("aigo_launcher.py", "w") as f:
    f.write(launcher)

# Build EXE
result = subprocess.run([
    "pyinstaller",
    "--onefile",
    "--windowed",
    "--name", "AIGO Media Setup",
    "--icon", "aigo_icon.ico",  # Need to add icon
    "aigo_launcher.py"
], capture_output=True, text=True)

if result.returncode == 0:
    print("✅ EXE built: dist/AIGO Media Setup.exe")
else:
    print("❌ Build failed:")
    print(result.stderr)
