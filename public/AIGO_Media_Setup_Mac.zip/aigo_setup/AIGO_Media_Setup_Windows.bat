@echo off
title MediaGoAI — AI Business Setup
color 0A
setlocal enabledelayedexpansion

set WORKSPACE=%USERPROFILE%\AIGOMedia
set LOG=%TEMP%\mediagoai_install.log
set PORT=8899

:: Open the branded installer UI first
echo Starting MediaGoAI installer...

:: Start local server for UI
start /b python -m http.server %PORT% --bind 127.0.0.1 --directory "%~dp0" > nul 2>&1

:: Open browser to installer
timeout /t 2 /nobreak > nul
start "" "http://127.0.0.1:%PORT%/installer_ui.html"

echo.
echo  ============================================
echo   MediaGoAI - OpenClaw AI Business Setup
echo  ============================================
echo.
echo  Installing everything automatically...
echo  This takes 5-15 minutes. Do NOT close this window.
echo.

:: ── STEP 1: Check system ─────────────────────────────────
echo  [1/6] Checking your system...
ver | findstr /i "10\. 11\." > nul 2>&1
if %errorlevel% neq 0 (
    echo  WARNING: Windows 10 or 11 recommended
)
echo  System check complete.

:: ── STEP 2: Install Node.js ──────────────────────────────
echo  [2/6] Checking Node.js...
where node > nul 2>&1
if %errorlevel% neq 0 (
    echo  Node.js not found. Downloading installer...
    
    :: Download Node.js LTS installer directly
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi' -OutFile '%TEMP%\node_installer.msi'}" >> %LOG% 2>&1
    
    if exist "%TEMP%\node_installer.msi" (
        echo  Installing Node.js...
        msiexec /i "%TEMP%\node_installer.msi" /quiet /norestart >> %LOG% 2>&1
        :: Refresh PATH
        set "PATH=%PATH%;C:\Program Files\nodejs"
        echo  Node.js installed.
    ) else (
        echo  Could not download Node.js automatically.
        echo  Please download from nodejs.org and run this installer again.
        pause
        exit /b 1
    )
) else (
    for /f "tokens=*" %%i in ('node --version 2^>nul') do echo  Node.js %%i already installed.
)

:: ── STEP 3: Install Python ───────────────────────────────
echo  [3/6] Checking Python...
where python > nul 2>&1
if %errorlevel% neq 0 (
    echo  Python not found. Downloading installer...
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.7/python-3.11.7-amd64.exe' -OutFile '%TEMP%\python_installer.exe'}" >> %LOG% 2>&1
    
    if exist "%TEMP%\python_installer.exe" (
        echo  Installing Python...
        "%TEMP%\python_installer.exe" /quiet InstallAllUsers=1 PrependPath=1 >> %LOG% 2>&1
        set "PATH=%PATH%;C:\Program Files\Python311;C:\Program Files\Python311\Scripts"
        echo  Python installed.
    ) else (
        echo  Could not download Python. Continuing...
    )
) else (
    for /f "tokens=*" %%i in ('python --version 2^>nul') do echo  %%i already installed.
)

:: ── STEP 4: Install Python packages ─────────────────────
echo  [4/6] Installing automation tools...
python -m pip install playwright anthropic --quiet >> %LOG% 2>&1
python -m playwright install chromium >> %LOG% 2>&1
echo  Automation tools ready.

:: ── STEP 5: Install OpenClaw ─────────────────────────────
echo  [5/6] Installing OpenClaw AI...
where openclaw > nul 2>&1
if %errorlevel% neq 0 (
    call npm install -g openclaw@latest >> %LOG% 2>&1
    echo  OpenClaw installed.
) else (
    echo  OpenClaw already installed. Updating...
    call npm install -g openclaw@latest >> %LOG% 2>&1
)

:: ── STEP 6: Configure workspace ──────────────────────────
echo  [6/6] Configuring your AI assistant...
if not exist "%WORKSPACE%" mkdir "%WORKSPACE%"
if not exist "%WORKSPACE%\config" mkdir "%WORKSPACE%\config"
if not exist "%WORKSPACE%\memory" mkdir "%WORKSPACE%\memory"
if not exist "%WORKSPACE%\scripts" mkdir "%WORKSPACE%\scripts"

:: Copy workspace files
if exist "%~dp0workspace_files\" (
    xcopy "%~dp0workspace_files\*" "%WORKSPACE%\" /E /Y /Q >> %LOG% 2>&1
)

:: Copy MediaGoAI Setup folder to Desktop
if exist "%~dp0workspace_files\MediaGoAI Setup\" (
    xcopy "%~dp0workspace_files\MediaGoAI Setup\*" "%USERPROFILE%\Desktop\MediaGoAI Setup\" /E /Y /Q >> %LOG% 2>&1
)

:: Configure OpenClaw
if not exist "%USERPROFILE%\.openclaw" mkdir "%USERPROFILE%\.openclaw"
if not exist "%USERPROFILE%\.openclaw\openclaw.json" (
    set WSPATH=%WORKSPACE:\=\\%
    (
        echo {
        echo   "agents": {
        echo     "defaults": {
        echo       "model": { "primary": "anthropic/claude-sonnet-4-6" },
        echo       "workspace": "%WORKSPACE%"
        echo     }
        echo   },
        echo   "tools": { "profile": "coding" },
        echo   "commands": { "native": "auto", "nativeSkills": "auto", "restart": true },
        echo   "gateway": { "port": 18789, "mode": "local", "bind": "loopback" }
        echo }
    ) > "%USERPROFILE%\.openclaw\openclaw.json"
)

:: Start OpenClaw
echo  Starting OpenClaw AI...
start /b openclaw gateway start >> %LOG% 2>&1
timeout /t 8 /nobreak > nul

:: ── DONE ─────────────────────────────────────────────────
echo.
echo  ============================================
echo   Installation Complete!
echo  ============================================
echo.
echo  Opening your AI assistant...
echo.

:: Open OpenClaw in browser
start "" "http://127.0.0.1:18789"
timeout /t 3 /nobreak > nul

:: Also open a helpful page if OpenClaw doesn't load
echo  If the AI assistant doesn't open automatically,
echo  go to: http://127.0.0.1:18789
echo.
echo  Your MediaGoAI Setup folder is on your Desktop.
echo  Fill out any file there to set up your services.
echo.
pause
