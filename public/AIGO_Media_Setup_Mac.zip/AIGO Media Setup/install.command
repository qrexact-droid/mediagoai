#!/bin/bash
# AIGO Media — AI Business Assistant Installer
# One click. Everything installs. No tech knowledge needed.

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

# Move to script directory
cd "$(dirname "$0")"

clear
echo ""
echo -e "${BOLD}╔════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║                                        ║${NC}"
echo -e "${BOLD}║     🤖  AIGO Media AI Assistant        ║${NC}"
echo -e "${BOLD}║         Business Setup Installer       ║${NC}"
echo -e "${BOLD}║                                        ║${NC}"
echo -e "${BOLD}╚════════════════════════════════════════╝${NC}"
echo ""

# ── License Key Validation ─────────────────────────────────
echo -e "  ${YELLOW}Enter your license key to continue.${NC}"
echo -e "  ${YELLOW}(Found in your purchase email)${NC}"
echo ""
read -p "  License Key: " LICENSE_KEY

if [ -z "$LICENSE_KEY" ]; then
  fail "No license key entered. Check your purchase email for your key."
fi

echo ""
echo -e "  Validating license key..."

# Get machine ID
MACHINE_ID=$(system_profiler SPHardwareDataType 2>/dev/null | grep "Serial Number" | awk '{print $NF}')
if [ -z "$MACHINE_ID" ]; then
  MACHINE_ID=$(hostname)
fi

# Validate key format: must be AIGO-XXXX-XXXX-XXXX
if ! echo "$LICENSE_KEY" | grep -qE '^AIGO-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$'; then
  fail "Invalid license key format. Keys look like: AIGO-X7K2-M9QP-3RFV\nCheck your purchase email and try again."
fi

# Validate against mediagoai.com API
RESPONSE=$(curl -s --max-time 10 -X POST "https://mediagoai.com/api/validate-key" \
  -H "Content-Type: application/json" \
  -d "{\"key\": \"$LICENSE_KEY\", \"machineId\": \"$MACHINE_ID\"}" 2>/dev/null)

if [ -n "$RESPONSE" ]; then
  VALID=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('valid','false'))" 2>/dev/null)
  CUSTOMER_NAME=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('name',''))" 2>/dev/null)
  KEY_ERROR=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('error',''))" 2>/dev/null)

  if [ "$VALID" != "True" ] && [ "$VALID" != "true" ]; then
    fail "License key rejected: ${KEY_ERROR:-Invalid key}. Contact aigo.mediapro@gmail.com for help."
  fi
else
  # API unreachable — allow install (key format already validated above)
  echo -e "  ${YELLOW}⚠️  Could not reach validation server — proceeding with format check only${NC}"
fi

echo -e "  ${GREEN}✅ License valid — Welcome${NC}${BOLD}${CUSTOMER_NAME:+, $CUSTOMER_NAME}${NC}${GREEN}!${NC}"
echo ""
echo -e "  Press ${BOLD}Enter${NC} to begin installation, or ${BOLD}Ctrl+C${NC} to cancel."
read -p "  > "

# ── Step tracking ──────────────────────────────────────────
STEPS=7
CURRENT=0

step() {
  CURRENT=$((CURRENT + 1))
  echo ""
  echo -e "${BLUE}${BOLD}[$CURRENT/$STEPS] $1${NC}"
}

ok() {
  echo -e "  ${GREEN}✅ $1${NC}"
}

warn() {
  echo -e "  ${YELLOW}⚠️  $1${NC}"
}

fail() {
  echo ""
  echo -e "${RED}${BOLD}❌ Installation failed: $1${NC}"
  echo ""
  echo -e "  Please contact support or visit aigo.media for help."
  echo ""
  read -p "  Press Enter to close..."
  exit 1
}

# ── Step 1: Check macOS ────────────────────────────────────
step "Checking your Mac"
OS=$(sw_vers -productVersion 2>/dev/null)
ARCH=$(uname -m)
ok "macOS $OS ($ARCH)"

# Check internet
curl -s --max-time 5 https://apple.com > /dev/null 2>&1 || fail "No internet connection detected. Please connect and try again."
ok "Internet connection active"

# ── Step 2: Homebrew ───────────────────────────────────────
step "Installing package manager (Homebrew)"
if command -v brew &>/dev/null; then
  ok "Homebrew already installed"
else
  echo "  Installing Homebrew... (may ask for your Mac password)"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" < /dev/null
  # Add to PATH for Apple Silicon
  if [ "$ARCH" = "arm64" ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
  fi
  command -v brew &>/dev/null || fail "Homebrew installation failed"
  ok "Homebrew installed"
fi

# ── Step 3: Node.js ────────────────────────────────────────
step "Installing Node.js"
if command -v node &>/dev/null; then
  NODE_VER=$(node --version)
  ok "Node.js already installed ($NODE_VER)"
else
  brew install node
  command -v node &>/dev/null || fail "Node.js installation failed"
  ok "Node.js installed"
fi

# ── Step 4: Python dependencies ───────────────────────────
step "Installing Python tools"
if ! command -v python3 &>/dev/null; then
  brew install python3
fi
ok "Python3 ready"

# Install pip packages
echo "  Installing automation libraries..."
pip3 install playwright anthropic --quiet --break-system-packages 2>/dev/null || \
pip3 install playwright anthropic --quiet 2>/dev/null
python3 -m playwright install chromium --quiet 2>/dev/null
ok "Automation libraries ready"

# ── Step 5: OpenClaw ──────────────────────────────────────
step "Installing OpenClaw AI Engine"
if command -v openclaw &>/dev/null; then
  ok "OpenClaw already installed"
  # Update to latest
  npm install -g openclaw@latest --quiet 2>/dev/null
  ok "Updated to latest version"
else
  npm install -g openclaw@latest
  command -v openclaw &>/dev/null || fail "OpenClaw installation failed"
  ok "OpenClaw installed"
fi

# ── Step 6: Configure OpenClaw ────────────────────────────
step "Configuring your AI assistant"

# Create workspace
WORKSPACE="$HOME/AIGOMedia"
mkdir -p "$WORKSPACE"
mkdir -p "$WORKSPACE/config"
mkdir -p "$WORKSPACE/memory"
mkdir -p "$WORKSPACE/scripts"

# Copy setup files from installer
if [ -d "$(dirname "$0")/workspace_files" ]; then
  cp -r "$(dirname "$0")/workspace_files/." "$WORKSPACE/"
  ok "Setup files installed"
fi

# Copy MediaGoAI Setup folder to Desktop
if [ -d "$(dirname "$0")/workspace_files/MediaGoAI Setup" ]; then
  cp -r "$(dirname "$0")/workspace_files/MediaGoAI Setup" "$HOME/Desktop/MediaGoAI Setup"
  ok "Setup folder added to Desktop"
else
  # Create minimal BOOTSTRAP.md so AI greets customer on first launch
  cat > "$WORKSPACE/BOOTSTRAP.md" <<'BOOT'
# First Launch

You are an AI business assistant. A new customer just installed you.

Send this message immediately — do not wait for them to speak first:

---
Hey! 👋 I'm your AI business assistant — I'm already up and running on your computer.

Here's what I can set up for you:

🌐 **Website** — type "build me a website"
📱 **Social Media** — type "set up my social media"
🎮 **Content Posting** — type "set up content posting"
📦 **Sell Online** — type "help me sell something online"

Just type what you want below and we'll get started. 👇
---

Ask their name and business type, then help them with whatever they choose.
Keep it simple — no tech talk. Delete this file when first setup is complete.
BOOT
  ok "Welcome message configured"
fi

# Configure OpenClaw to use the workspace
mkdir -p ~/.openclaw
if [ ! -f ~/.openclaw/openclaw.json ]; then
  cat > ~/.openclaw/openclaw.json <<EOF
{
  "agents": {
    "defaults": {
      "model": { "primary": "anthropic/claude-sonnet-4-6" },
      "workspace": "$WORKSPACE"
    }
  },
  "tools": { "profile": "coding" },
  "commands": { "native": "auto", "nativeSkills": "auto", "restart": true },
  "gateway": {
    "port": 18789,
    "mode": "local",
    "bind": "loopback"
  }
}
EOF
  ok "OpenClaw configured"
else
  ok "OpenClaw config already exists"
fi

# Start gateway
openclaw gateway start 2>/dev/null
sleep 3
ok "AI engine started"

# ── Step 7: Launch Setup Wizard ───────────────────────────
step "Launching your setup wizard"
sleep 2

# Open the setup wizard in browser
open "http://127.0.0.1:18789" 2>/dev/null || open "http://localhost:18789"

echo ""
echo -e "${GREEN}${BOLD}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║                                        ║${NC}"
echo -e "${GREEN}${BOLD}║   ✅  Installation Complete!           ║${NC}"
echo -e "${GREEN}${BOLD}║                                        ║${NC}"
echo -e "${GREEN}${BOLD}║   Your browser should open with        ║${NC}"
echo -e "${GREEN}${BOLD}║   your AI assistant setup wizard.      ║${NC}"
echo -e "${GREEN}${BOLD}║                                        ║${NC}"
echo -e "${GREEN}${BOLD}║   If it didn't open, go to:            ║${NC}"
echo -e "${GREEN}${BOLD}║   http://127.0.0.1:18789               ║${NC}"
echo -e "${GREEN}${BOLD}║                                        ║${NC}"
echo -e "${GREEN}${BOLD}╚════════════════════════════════════════╝${NC}"
echo ""
read -p "  Press Enter to close this window..."
