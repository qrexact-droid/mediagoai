#!/bin/bash
# AIGO Media — AI Business Installer (Mac)

# Move to script directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Kill anything on our ports
lsof -ti:8899 | xargs kill -9 2>/dev/null
sleep 1

# ── Start local web server for installer UI ──────────────────────
python3 -c "
import http.server, os, json

PORT = 8899
SCRIPT_DIR = '$SCRIPT_DIR'

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass

    def do_GET(self):
        # Serve files by path
        path_map = {
            '/':          'installer_ui.html',
            '/installer': 'installer_ui.html',
            '/wizard':    'wizard.html',
        }
        fname = path_map.get(self.path)
        if fname:
            fpath = os.path.join(SCRIPT_DIR, fname)
            if os.path.exists(fpath):
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(open(fpath, 'rb').read())
                return
        # Check install status
        if self.path == '/install-status':
            log = '/tmp/aigo_install.log'
            done = os.path.exists(log) and 'INSTALL_COMPLETE' in open(log).read()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'done': done}).encode())
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if self.path == '/api/setup':
            try:
                length = int(self.headers.get('Content-Length', 0))
                data = json.loads(self.rfile.read(length)) if length else {}
                ws = os.path.expanduser('~/AIGOMedia')
                os.makedirs(ws + '/config', exist_ok=True)
                with open(ws + '/config/setup.json', 'w') as f:
                    json.dump(data, f, indent=2)
            except: pass
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{\"ok\": true}')
        else:
            self.send_response(404)
            self.end_headers()

server = http.server.HTTPServer(('127.0.0.1', PORT), Handler)
server.serve_forever()
" &

SERVER_PID=$!
sleep 1

# Open installer UI
open "http://127.0.0.1:8899/installer"

# ── Run full install in background ───────────────────────────────
(
  LOG=/tmp/aigo_install.log
  > "$LOG"
  echo "[$(date)] Starting install..." >> "$LOG"

  # ── Homebrew ───────────────────────────────────────────────────
  if ! command -v brew &>/dev/null; then
    echo "[$(date)] Installing Homebrew..." >> "$LOG"
    NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" >> "$LOG" 2>&1
  fi

  # Load Homebrew into PATH (works for both Intel and Apple Silicon)
  if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
    export PATH="/opt/homebrew/bin:$PATH"
  elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
    export PATH="/usr/local/bin:$PATH"
  fi
  echo "[$(date)] brew: $(which brew 2>/dev/null || echo 'not found')" >> "$LOG"

  # ── Node.js ────────────────────────────────────────────────────
  if ! command -v node &>/dev/null; then
    echo "[$(date)] Installing Node.js..." >> "$LOG"
    brew install node >> "$LOG" 2>&1
  fi
  # Ensure node is in PATH after brew install
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
  echo "[$(date)] node: $(which node 2>/dev/null || echo 'not found')" >> "$LOG"

  # ── Python packages ────────────────────────────────────────────
  echo "[$(date)] Installing Python packages..." >> "$LOG"
  pip3 install playwright anthropic --quiet --break-system-packages >> "$LOG" 2>&1 || \
  pip3 install playwright anthropic --quiet >> "$LOG" 2>&1
  python3 -m playwright install chromium --quiet >> "$LOG" 2>&1

  # ── OpenClaw ───────────────────────────────────────────────────
  echo "[$(date)] Installing OpenClaw..." >> "$LOG"
  npm install -g openclaw@latest >> "$LOG" 2>&1

  # CRITICAL: Find openclaw binary — npm puts it in the global prefix bin
  NPM_BIN="$(npm config get prefix)/bin"
  export PATH="$NPM_BIN:/opt/homebrew/bin:/usr/local/bin:$PATH"
  OPENCLAW_BIN="$(which openclaw 2>/dev/null || echo "$NPM_BIN/openclaw")"
  echo "[$(date)] openclaw: $OPENCLAW_BIN" >> "$LOG"

  # ── Workspace ──────────────────────────────────────────────────
  WORKSPACE="$HOME/AIGOMedia"
  mkdir -p "$WORKSPACE/config" "$WORKSPACE/memory" "$WORKSPACE/scripts"
  if [ -d "$SCRIPT_DIR/workspace_files" ]; then
    cp -r "$SCRIPT_DIR/workspace_files/." "$WORKSPACE/"
  fi

  # ── OpenClaw config ────────────────────────────────────────────
  mkdir -p ~/.openclaw
  if [ ! -f ~/.openclaw/openclaw.json ]; then
    cat > ~/.openclaw/openclaw.json << OCCONF
{
  "agents": {
    "defaults": {
      "model": { "primary": "anthropic/claude-sonnet-4-6" },
      "workspace": "$WORKSPACE"
    }
  },
  "tools": { "profile": "coding" },
  "commands": { "native": "auto", "nativeSkills": "auto", "restart": true },
  "gateway": { "port": 18789, "mode": "local", "bind": "loopback" }
}
OCCONF
  fi

  # Write API key if captured from wizard
  SETUP_JSON="$WORKSPACE/config/setup.json"
  if [ -f "$SETUP_JSON" ]; then
    API_KEY=$(python3 -c "import json; d=json.load(open('$SETUP_JSON')); print(d.get('user',{}).get('apiKey',''))" 2>/dev/null)
    if [ -n "$API_KEY" ]; then
      "$OPENCLAW_BIN" config set agents.defaults.apiKey "$API_KEY" >> "$LOG" 2>&1 || true
      # Also write to env-style config as fallback
      echo "ANTHROPIC_API_KEY=$API_KEY" > ~/.openclaw/.env 2>/dev/null || true
    fi
  fi

  # ── Start OpenClaw gateway ─────────────────────────────────────
  echo "[$(date)] Starting OpenClaw gateway..." >> "$LOG"
  "$OPENCLAW_BIN" gateway start >> "$LOG" 2>&1 &
  GATEWAY_PID=$!

  # Poll until port 18789 is up (max 3 min)
  WAITED=0
  until nc -z 127.0.0.1 18789 2>/dev/null || [ $WAITED -ge 180 ]; do
    sleep 2; WAITED=$((WAITED+2))
    echo "[$(date)] Waiting for gateway... ${WAITED}s" >> "$LOG"
  done

  if nc -z 127.0.0.1 18789 2>/dev/null; then
    echo "[$(date)] Gateway is UP on port 18789" >> "$LOG"
  else
    echo "[$(date)] WARNING: Gateway did not respond after ${WAITED}s" >> "$LOG"
  fi

  echo "INSTALL_COMPLETE" >> "$LOG"
  echo "[$(date)] Done." >> "$LOG"
) &

# Keep python server running until the user is done
wait $SERVER_PID
