#!/bin/bash
# AIGO Media — Professional Installer
# Hides terminal ugliness, shows a clean browser-based installer

# Immediately hide this terminal window
osascript -e 'tell application "Terminal" to set miniaturized of front window to true' 2>/dev/null &

# Move to script directory
cd "$(dirname "$0")"

# Kill any existing setup server
lsof -ti:8899 | xargs kill -9 2>/dev/null

# Start the GUI installer server in background
python3 -c "
import http.server, threading, os, json, subprocess, sys, time

PORT = 8899
SCRIPT_DIR = os.path.dirname(os.path.abspath('$0'))
WORKSPACE = os.path.expanduser('~/AIGOMedia')

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass  # Silent

    def do_GET(self):
        if self.path == '/' or self.path == '/installer':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(open(os.path.join(SCRIPT_DIR, 'installer_ui.html'), 'rb').read())
        elif self.path == '/wizard':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(open(os.path.join(SCRIPT_DIR, 'wizard.html'), 'rb').read())
        elif self.path == '/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{\"status\": \"ready\"}')
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/install':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            # Run install in background, stream status
            self.wfile.write(b'{\"started\": true}')
        elif self.path == '/api/setup':
            length = int(self.headers.get('Content-Length', 0))
            data = json.loads(self.rfile.read(length))
            os.makedirs(WORKSPACE + '/config', exist_ok=True)
            with open(WORKSPACE + '/config/setup.json', 'w') as f:
                json.dump(data, f, indent=2)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{\"ok\": true}')

server = http.server.HTTPServer(('127.0.0.1', PORT), Handler)
server.serve_forever()
" &

SERVER_PID=$!
sleep 1

# Open the branded installer in browser
open "http://127.0.0.1:8899/installer"

# Run actual installation silently in background
(
  # Homebrew
  if ! command -v brew &>/dev/null; then
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" < /dev/null > /tmp/aigo_install.log 2>&1
    if [ "$(uname -m)" = "arm64" ]; then
      eval "$(/opt/homebrew/bin/brew shellenv)"
      echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
    fi
  fi

  # Node
  if ! command -v node &>/dev/null; then
    brew install node >> /tmp/aigo_install.log 2>&1
  fi

  # Python deps
  pip3 install playwright anthropic --quiet --break-system-packages >> /tmp/aigo_install.log 2>&1 || \
  pip3 install playwright anthropic --quiet >> /tmp/aigo_install.log 2>&1
  python3 -m playwright install chromium --quiet >> /tmp/aigo_install.log 2>&1

  # OpenClaw
  npm install -g openclaw@latest --quiet >> /tmp/aigo_install.log 2>&1

  # Workspace
  WORKSPACE="$HOME/AIGOMedia"
  mkdir -p "$WORKSPACE/config" "$WORKSPACE/memory" "$WORKSPACE/scripts"

  # Copy workspace files
  if [ -d "$(dirname "$0")/workspace_files" ]; then
    cp -r "$(dirname "$0")/workspace_files/." "$WORKSPACE/"
  fi

  # Configure OpenClaw
  mkdir -p ~/.openclaw
  if [ ! -f ~/.openclaw/openclaw.json ]; then
    cat > ~/.openclaw/openclaw.json <<EOF
{
  "agents": {
    "defaults": {
      "model": { "primary": "anthropic/claude-sonnet-4-6" },
      "workspace": "$WORKSPACE"
    }
  },
  "tools": { "profile": "coding" },
  "commands": { "native": "auto", "nativeSkills": "auto", "restart": true },
  "gateway": { "port": 18789, "mode": "local", "bind": "loopback" }
}
EOF
  fi

  # Start OpenClaw gateway
  openclaw gateway start >> /tmp/aigo_install.log 2>&1

  # Poll until port 18789 is accepting connections (max 2 min)
  MAX_WAIT=120
  WAITED=0
  until nc -z 127.0.0.1 18789 2>/dev/null || [ $WAITED -ge $MAX_WAIT ]; do
    sleep 2
    WAITED=$((WAITED+2))
  done

  echo "INSTALL_COMPLETE" >> /tmp/aigo_install.log
) &

# Keep server alive until user is done
wait $SERVER_PID
